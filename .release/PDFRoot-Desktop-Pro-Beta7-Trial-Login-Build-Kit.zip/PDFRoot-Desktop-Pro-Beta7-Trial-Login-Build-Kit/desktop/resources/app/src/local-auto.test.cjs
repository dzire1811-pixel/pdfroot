const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { PDFDocument } = require("pdf-lib");
const { Jimp, JimpMime } = require("jimp");
const {
  localAutoSlugs,
  PDF_COMPRESSION_PRESETS,
  PDF_TO_JPG_RENDER_OPTIONS,
  processLocalAutoJob,
} = require("./local-auto.cjs");
const { frontBackPreviews } = require("./front-back-preview.cjs");

async function makeFixtureDirectory() {
  const directory = await fs.promises.mkdtemp(path.join(os.tmpdir(), "pdfroot-local-auto-"));
  const image = new Jimp({ width: 300, height: 180, color: 0x2d7ff9ff });
  const image2 = new Jimp({ width: 220, height: 220, color: 0xffbd2eff });
  const jpg = path.join(directory, "photo.jpg");
  const png = path.join(directory, "photo.png");
  await fs.promises.writeFile(jpg, await image.getBuffer(JimpMime.jpeg, { quality: 92 }));
  await fs.promises.writeFile(png, await image2.getBuffer(JimpMime.png));
  const pdfOne = await PDFDocument.create();
  pdfOne.addPage([200, 200]);
  const pdfTwo = await PDFDocument.create();
  pdfTwo.addPage([200, 200]);
  const firstPdf = path.join(directory, "one.pdf");
  const secondPdf = path.join(directory, "two.pdf");
  await fs.promises.writeFile(firstPdf, await pdfOne.save());
  await fs.promises.writeFile(secondPdf, await pdfTwo.save());
  return { directory, jpg, png, firstPdf, secondPdf };
}

test("common image and PDF Auto Mode workflows are local-first", () => {
  for (const slug of ["jpg-to-pdf", "merge-pdf", "compress-pdf", "compress-image", "resize-image-to-exact-kb", "front-back-card-merge"]) {
    assert.equal(localAutoSlugs.has(slug), true, `${slug} should not open the website window`);
  }
});

test("JPG to PDF and Merge PDF save a usable result in the selected folder", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    const jpgResult = await processLocalAutoJob({
      slug: "jpg-to-pdf",
      files: [fixture.jpg, fixture.png],
      outputDirectory: fixture.directory,
    });
    assert.equal(jpgResult.handled, true);
    assert.equal(jpgResult.outputPaths.length, 1);
    assert.equal(path.dirname(jpgResult.outputPaths[0]), fixture.directory);
    assert.equal((await PDFDocument.load(await fs.promises.readFile(jpgResult.outputPaths[0]))).getPageCount(), 2);

    const mergeResult = await processLocalAutoJob({
      slug: "merge-pdf",
      files: [fixture.firstPdf, fixture.secondPdf],
      outputDirectory: fixture.directory,
    });
    assert.equal(mergeResult.handled, true);
    assert.equal((await PDFDocument.load(await fs.promises.readFile(mergeResult.outputPaths[0]))).getPageCount(), 2);
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("JPG to PDF creates one page per image in the preview order", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    const result = await processLocalAutoJob({
      slug: "jpg-to-pdf", files: [fixture.jpg, fixture.png],
      outputDirectory: fixture.directory, pageOrder: ["1:0", "0:0"],
    });
    const pdf = await PDFDocument.load(await fs.promises.readFile(result.outputPaths[0]));
    assert.equal(pdf.getPageCount(), 2);
    assert.deepEqual(pdf.getPage(0).getSize(), { width: 220, height: 220 });
    assert.deepEqual(pdf.getPage(1).getSize(), { width: 300, height: 180 });
    await assert.rejects(() => processLocalAutoJob({
      slug: "jpg-to-pdf", files: [fixture.jpg, fixture.png],
      outputDirectory: fixture.directory, pageOrder: ["0:0", "0:0"],
    }), /order is invalid/);
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("Merge PDF reorders individual pages from multiple source PDFs", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    const first = await PDFDocument.create();
    first.addPage([210, 310]);
    const second = await PDFDocument.create();
    second.addPage([220, 320]);
    second.addPage([230, 330]);
    await fs.promises.writeFile(fixture.firstPdf, await first.save());
    await fs.promises.writeFile(fixture.secondPdf, await second.save());
    const result = await processLocalAutoJob({
      slug: "merge-pdf", files: [fixture.firstPdf, fixture.secondPdf],
      outputDirectory: fixture.directory, pageOrder: ["1:1", "0:0", "1:0"],
    });
    const pdf = await PDFDocument.load(await fs.promises.readFile(result.outputPaths[0]));
    assert.deepEqual(pdf.getPages().map((page) => page.getSize()), [
      { width: 230, height: 330 }, { width: 210, height: 310 }, { width: 220, height: 320 },
    ]);
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("image Auto Mode creates a requested exact KB image and a signature", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    const exactResult = await processLocalAutoJob({
      slug: "resize-image-to-exact-kb",
      files: [fixture.jpg],
      outputDirectory: fixture.directory,
      targetKb: 75,
    });
    const signatureResult = await processLocalAutoJob({
      slug: "signature-resize-tool",
      files: [fixture.png],
      outputDirectory: fixture.directory,
    });
    assert.equal((await fs.promises.stat(exactResult.outputPaths[0])).size, 75 * 1024);
    assert.match(path.basename(exactResult.outputPaths[0]), /75KB\.jpg$/);
    assert.ok((await Jimp.read(exactResult.outputPaths[0])).width > 0);
    const signature = await Jimp.read(await fs.promises.readFile(signatureResult.outputPaths[0]));
    assert.equal(signature.width, 140);
    assert.equal(signature.height, 60);
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("OJAS and GPSC print the chosen date, with today's date as the blank default", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    for (const [slug, width, height] of [["ojas-photo-resize", 425, 591], ["gpsc-photo-resize", 300, 400]]) {
      const dated = await processLocalAutoJob({
        slug, files: [fixture.jpg], outputDirectory: fixture.directory, photoDate: "2026-10-01",
      });
      assert.match(path.basename(dated.outputPaths[0]), /2026-10-01\.jpg$/);
      const image = await Jimp.read(dated.outputPaths[0]);
      assert.equal(image.width, width);
      assert.equal(image.height, height);
      if (slug === "gpsc-photo-resize") {
        assert.ok((await fs.promises.stat(dated.outputPaths[0])).size < 15 * 1024);
      }
      const stripPixels = Array.from({ length: width - 40 }, (_, index) => image.getPixelColor(index + 20, height - 17));
      assert.ok(stripPixels.some((color) => (color >>> 24) < 130), "date should have visible dark ink");
      const inkRows = Array.from({ length: 52 }, (_, row) => row).filter((row) =>
        Array.from({ length: width - 40 }, (_, index) => image.getPixelColor(index + 20, height - 52 + row))
          .some((color) => (color >>> 24) < 130));
      assert.ok(inkRows.length >= 18, "date should be tall and readable at output size");
      const different = await processLocalAutoJob({
        slug, files: [fixture.jpg], outputDirectory: fixture.directory, photoDate: "2026-10-02",
      });
      assert.notDeepEqual(await fs.promises.readFile(dated.outputPaths[0]), await fs.promises.readFile(different.outputPaths[0]));
      if (slug === "gpsc-photo-resize") {
        assert.ok((await fs.promises.stat(different.outputPaths[0])).size < 15 * 1024);
      }
      const today = await processLocalAutoJob({ slug, files: [fixture.jpg], outputDirectory: fixture.directory });
      assert.match(path.basename(today.outputPaths[0]), /\d{4}-\d{2}-\d{2}(?: \(\d+\))?\.jpg$/);
    }
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("recruitment shortcuts locally prepare their selected image type", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    for (const [slug, kind, width, height] of [
      ["ssc-photo-resize", "signature", 600, 200],
      ["rrb-signature-resize", undefined, 140, 60],
      ["ibps-photo-resize", "thumb", 240, 240],
      ["upsc-photo-resize", "photo", 350, 450],
    ]) {
      const result = await processLocalAutoJob({
        slug, files: [fixture.png], outputDirectory: fixture.directory, imageKind: kind,
      });
      assert.equal(result.handled, true);
      const image = await Jimp.read(result.outputPaths[0]);
      assert.equal(image.width, width);
      assert.equal(image.height, height);
      assert.equal(path.dirname(result.outputPaths[0]), fixture.directory);
      if (slug === "rrb-signature-resize") {
        const size = (await fs.promises.stat(result.outputPaths[0])).size;
        assert.ok(size > 30 * 1024 && size < 49 * 1024, `RRB signature size ${size} is outside the interior of 30–49 KB`);
        assert.ok(size >= 39 * 1024 && size <= 41 * 1024, `RRB signature size ${size} should be near 40 KB`);
      }
    }
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("Front and Back preview both images and honor a swapped order", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    const previews = await frontBackPreviews([fixture.jpg, fixture.png]);
    assert.deepEqual(previews.map((image) => image.name), ["photo.jpg", "photo.png"]);
    assert.ok(previews.every((image) => image.preview.startsWith("data:image/jpeg;base64,")));
    const result = await processLocalAutoJob({
      slug: "front-back-card-merge",
      files: [fixture.png, fixture.jpg],
      outputDirectory: fixture.directory,
    });
    const merged = await Jimp.read(result.outputPaths[0]);
    const top = merged.getPixelColor(20, 20);
    const bottom = merged.getPixelColor(20, merged.height - 20);
    assert.ok((top >>> 24) > (bottom >>> 24), "orange image should be on top");
    assert.ok(((bottom >>> 8) & 255) > ((top >>> 8) & 255), "blue image should be below");
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("Compress PDF has Normal, Low, and Heavy local output levels", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    const pageJpeg = (await fs.promises.readFile(fixture.jpg)).toString("base64");
    for (const level of Object.keys(PDF_COMPRESSION_PRESETS)) {
      let receivedRenderOptions;
      const result = await processLocalAutoJob({
        slug: "compress-pdf",
        files: [fixture.firstPdf],
        outputDirectory: fixture.directory,
        compressionLevel: level,
        renderPdfToJpg: async (_filePath, options) => {
          receivedRenderOptions = options;
          return [pageJpeg];
        },
      });
      assert.equal(result.handled, true);
      assert.equal(result.outputPaths.length, 1);
      assert.equal(path.dirname(result.outputPaths[0]), fixture.directory);
      if (level === "normal") assert.match(path.basename(result.outputPaths[0]), /compressed-normal\.pdf$/);
      else {
        // This tiny PDF is already smaller than a rasterized page.
        assert.match(path.basename(result.outputPaths[0]), /compressed-normal-fallback(?: \(\d+\))?\.pdf$/);
        assert.match(result.warnings.join(" "), /did not make the PDF smaller/);
      }
      assert.equal((await PDFDocument.load(await fs.promises.readFile(result.outputPaths[0]))).getPageCount(), 1);
      if (level === "normal") assert.equal(receivedRenderOptions, undefined);
      else assert.deepEqual(receivedRenderOptions, PDF_COMPRESSION_PRESETS[level].renderOptions);
    }
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("Compress PDF saves a valid Normal fallback when Low or Heavy rendering fails", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    for (const level of ["low", "heavy"]) {
      const result = await processLocalAutoJob({
        slug: "compress-pdf",
        files: [fixture.firstPdf],
        outputDirectory: fixture.directory,
        compressionLevel: level,
        renderPdfToJpg: async () => { throw new Error("The local PDF renderer failed"); },
      });
      assert.equal(result.handled, true);
      assert.match(path.basename(result.outputPaths[0]), /compressed-normal-fallback(?: \(\d+\))?\.pdf$/);
      assert.match(result.warnings.join(" "), /rendering failed; saved a Normal PDF/);
      assert.equal((await PDFDocument.load(await fs.promises.readFile(result.outputPaths[0]))).getPageCount(), 1);
    }
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("Heavy compression embeds small JPEG pages without a pooled Buffer offset failure", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    const tinyJpeg = await new Jimp({ width: 35, height: 35, color: 0xffffffff })
      .getBuffer(JimpMime.jpeg, { quality: 60 });
    assert.ok(tinyJpeg.length < 8192);
    const result = await processLocalAutoJob({
      slug: "compress-pdf",
      files: [fixture.firstPdf],
      outputDirectory: fixture.directory,
      compressionLevel: "heavy",
      renderPdfToJpg: async () => [tinyJpeg.toString("base64")],
    });
    assert.doesNotMatch(result.warnings.join(" "), /rendering failed|SOI not found/);
    const saved = await PDFDocument.load(await fs.promises.readFile(result.outputPaths[0]));
    assert.equal(saved.getPageCount(), 1);
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});

test("PDF to JPG creates direct same-folder pages through the invisible local renderer", async () => {
  const fixture = await makeFixtureDirectory();
  try {
    const pageJpeg = (await fs.promises.readFile(fixture.jpg)).toString("base64");
    let receivedRenderOptions;
    const result = await processLocalAutoJob({
      slug: "pdf-to-jpg",
      files: [fixture.firstPdf],
      outputDirectory: fixture.directory,
      renderPdfToJpg: async (_filePath, options) => {
        receivedRenderOptions = options;
        return [pageJpeg, pageJpeg];
      },
    });
    assert.equal(result.handled, true);
    assert.equal(result.outputPaths.length, 2);
    assert.equal(path.dirname(result.outputPaths[0]), fixture.directory);
    assert.deepEqual(result.outputPaths.map((filePath) => path.basename(filePath)), ["one-page-1.jpg", "one-page-2.jpg"]);
    assert.deepEqual(receivedRenderOptions, PDF_TO_JPG_RENDER_OPTIONS);
    assert.deepEqual(await fs.promises.readFile(result.outputPaths[0]), Buffer.from(pageJpeg, "base64"));
  } finally {
    await fs.promises.rm(fixture.directory, { recursive: true, force: true });
  }
});
