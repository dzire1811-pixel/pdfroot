const assert = require("node:assert/strict");
const test = require("node:test");
const { parseExplorerPaths } = require("./windows-explorer.cjs");

test("Explorer selection parsing preserves only existing selected paths", () => {
  const first = "C:\\Forms\\photo.jpg";
  const second = "C:\\Forms\\document.pdf";
  const parsed = parseExplorerPaths(JSON.stringify([first, second]), (filePath) => filePath === first);
  assert.deepEqual(parsed, [first]);
});

test("Explorer selection parsing safely ignores empty or malformed output", () => {
  assert.deepEqual(parseExplorerPaths("", () => true), []);
  assert.deepEqual(parseExplorerPaths("not-json", () => true), []);
});

