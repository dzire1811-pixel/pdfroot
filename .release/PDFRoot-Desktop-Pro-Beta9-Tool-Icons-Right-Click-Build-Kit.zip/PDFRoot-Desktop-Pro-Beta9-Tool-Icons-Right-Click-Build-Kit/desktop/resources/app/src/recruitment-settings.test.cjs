const assert = require("node:assert/strict");
const test = require("node:test");
const { parseTargetKb, parsePhotoDate, localDate, presetFor } = require("./recruitment-settings.cjs");

test("Exact KB accepts only supported whole numbers", () => {
  assert.equal(parseTargetKb("50"), 50);
  assert.equal(parseTargetKb("12.5"), undefined);
  assert.equal(parseTargetKb("0"), undefined);
  assert.equal(parseTargetKb("2049"), undefined);
});

test("Date picker uses local calendar date and rejects invalid dates", () => {
  const today = new Date(2026, 9, 1);
  assert.equal(localDate(today), "2026-10-01");
  assert.deepEqual(parsePhotoDate("", today), { iso: "2026-10-01", display: "01/10/2026" });
  assert.equal(parsePhotoDate("2026-02-30"), undefined);
  assert.equal(parsePhotoDate("2026-02-28").display, "28/02/2026");
  assert.equal(presetFor("ibps-photo-resize", "thumb").width, 240);
  assert.equal(presetFor("gpsc-photo-resize", "photo").strictlyUnder, true);
});
