"use strict";
const fs = require("node:fs");
const path = require("node:path");

function accountServiceError(data, status) {
  const error = data && data.error;
  const message = typeof error === "string" ? error
    : typeof error?.message === "string" ? error.message
    : typeof data?.message === "string" ? data.message : "";
  return message || `PDFRoot account service could not respond (HTTP ${status}).`;
}

class AccountClient {
  constructor({ baseUrl, userDataPath, deviceId, licenseStore, fetchImpl = fetch }) {
    this.baseUrl = baseUrl;
    this.deviceId = deviceId;
    this.licenseStore = licenseStore;
    this.fetchImpl = fetchImpl;
    this.sessionPath = path.join(userDataPath, "account-session.json");
  }
  session() {
    try {
      const result = JSON.parse(fs.readFileSync(this.sessionPath, "utf8"));
      return result.token && Date.parse(result.expiresAt) > Date.now() ? result : null;
    } catch { return null; }
  }
  async request(route, payload, auth = false) {
    if (!this.baseUrl) throw new Error("Account service is unavailable.");
    const headers = { "Content-Type": "application/json" };
    if (auth) {
      const session = this.session();
      if (!session) throw new Error("Sign in with your email first.");
      headers.Authorization = `Bearer ${session.token}`;
    }
    const response = await this.fetchImpl(this.baseUrl + route, {
      method: payload === undefined ? "GET" : "POST", headers,
      ...(payload === undefined ? {} : { body: JSON.stringify(payload) }),
      signal: AbortSignal.timeout(12000),
    });
    let data;
    try { data = await response.json(); }
    catch { throw new Error(`PDFRoot account service could not respond (HTTP ${response.status}).`); }
    if (!response.ok) throw new Error(accountServiceError(data, response.status));
    return data;
  }
  async sendCode(email) {
    return this.request("/v1/account/send-code", { email: String(email || "").trim().toLowerCase() });
  }
  async verifyCode(email, code) {
    const result = await this.request("/v1/account/verify-code", { email: String(email || "").trim().toLowerCase(), code });
    if (!/^[A-Za-z0-9_-]{40,60}$/.test(result.token || "") || !result.email || !Number.isFinite(Date.parse(result.expiresAt))) {
      throw new Error("The account service returned an invalid sign-in.");
    }
    const session = { ...result, provider: "email" };
    fs.writeFileSync(this.sessionPath, JSON.stringify(session), { mode: 0o600 });
    return { email: result.email, provider: "email" };
  }
  async googleSignIn(idToken, nonce) {
    const result = await this.request("/v1/account/google", { idToken, nonce });
    if (!/^[A-Za-z0-9_-]{40,60}$/.test(result.token || "") || !result.email || !Number.isFinite(Date.parse(result.expiresAt))) {
      throw new Error("The account service returned an invalid Google sign-in.");
    }
    const session = { ...result, provider: "google" };
    fs.writeFileSync(this.sessionPath, JSON.stringify(session), { mode: 0o600 });
    return { email: result.email, name: typeof result.name === "string" ? result.name : "", provider: "google" };
  }
  async startTrial() {
    const result = await this.request("/v1/account/trial", { deviceId: this.deviceId }, true);
    const status = this.licenseStore.activate(result.code);
    if (!status.ok) throw new Error(status.message);
    return status;
  }
  async summary() {
    return this.request(`/v1/account/summary?deviceId=${encodeURIComponent(this.deviceId)}`, undefined, true);
  }
  async syncLicense() {
    if (!this.session()) return { state: "none" };
    const result = await this.request(`/v1/account/license?deviceId=${encodeURIComponent(this.deviceId)}`, undefined, true);
    if (result.state !== "active") return { state: "none" };
    const status = this.licenseStore.activate(result.code);
    if (!status.ok) throw new Error(status.message);
    return { state: "active", status };
  }
}
module.exports = { AccountClient };
