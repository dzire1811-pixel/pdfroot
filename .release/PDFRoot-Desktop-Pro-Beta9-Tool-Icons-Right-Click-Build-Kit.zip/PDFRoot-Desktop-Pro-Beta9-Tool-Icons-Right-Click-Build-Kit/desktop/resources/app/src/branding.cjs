const officialPdfRootLogoSvg = [
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="65 65 382 382" fill="none" shape-rendering="geometricPrecision" role="img" aria-label="PDFRoot">',
  '<path d="M323 144V121A28 28 0 0 0 295 93H121A28 28 0 0 0 93 121V295A28 28 0 0 0 121 323H295A28 28 0 0 0 323 295V232" stroke="#B91C1C" stroke-width="34" stroke-linecap="round" stroke-linejoin="round"/>',
  '<path d="M189 368V391A28 28 0 0 0 217 419H391A28 28 0 0 0 419 391V217A28 28 0 0 0 391 189H217A28 28 0 0 0 189 217V280" stroke="#111111" stroke-width="34" stroke-linecap="round" stroke-linejoin="round"/>',
  '</svg>',
].join("");

function desktopBrandInjectionScript({ mode = "normal" } = {}) {
  const auto = mode === "auto";
  const config = JSON.stringify({
    mode: auto ? "auto" : "normal",
    state: auto ? "AUTO MODE" : "DESKTOP MODE",
    logo: "data:image/svg+xml;charset=utf-8," + encodeURIComponent(officialPdfRootLogoSvg),
  });

  return [
    "(() => {",
    "  const config = " + config + ";",
    "  const badgeId = 'pdfroot-desktop-brand-badge';",
    "  const styleId = 'pdfroot-desktop-brand-style';",
    "  const addBrand = () => {",
    "    const host = document.body || document.documentElement;",
    "    if (!host) return;",
    "    let style = document.getElementById(styleId);",
    "    if (!style) {",
    "      style = document.createElement('style');",
    "      style.id = styleId;",
    "      style.textContent = '#'+badgeId+'{position:fixed!important;top:78px!important;right:20px!important;z-index:2147483000!important;display:flex!important;align-items:center!important;gap:9px!important;padding:8px 10px!important;border:1px solid #d9dde5!important;border-radius:10px!important;background:#ffffff!important;color:#111827!important;box-shadow:0 8px 24px rgba(17,24,39,.12)!important;font:600 12px/1.15 Segoe UI,Arial,sans-serif!important;letter-spacing:0!important;pointer-events:none!important}#'+badgeId+' img{display:block!important;width:24px!important;height:24px!important;flex:0 0 auto!important}#'+badgeId+' .pdfroot-desktop-brand-copy{display:grid!important;gap:2px!important}#'+badgeId+' strong{display:block!important;margin:0!important;color:#111827!important;font:800 12px/1.1 Segoe UI,Arial,sans-serif!important}#'+badgeId+' span{display:block!important;margin:0!important;color:#6b7280!important;font:800 9px/1 Segoe UI,Arial,sans-serif!important;letter-spacing:.09em!important}#'+badgeId+'[data-mode=auto] span{color:#b91c1c!important}@media(max-width:980px){#'+badgeId+'{top:66px!important;right:12px!important}}';",
    "      (document.head || host).appendChild(style);",
    "    }",
    "    let badge = document.getElementById(badgeId);",
    "    if (!badge) {",
    "      badge = document.createElement('aside');",
    "      badge.id = badgeId;",
    "      badge.setAttribute('aria-label', 'PDFRoot Desktop Pro');",
    "      badge.innerHTML = '<img alt=\"\" /><div class=\"pdfroot-desktop-brand-copy\"><strong>PDFRoot Desktop Pro</strong><span></span></div>';",
    "      host.appendChild(badge);",
    "    }",
    "    badge.dataset.mode = config.mode;",
    "    const image = badge.querySelector('img');",
    "    if (image) image.src = config.logo;",
    "    const state = badge.querySelector('span');",
    "    if (state) state.textContent = config.state;",
    "  };",
    "  addBrand();",
    "})();",
  ].join("\n");
}

module.exports = { officialPdfRootLogoSvg, desktopBrandInjectionScript };
