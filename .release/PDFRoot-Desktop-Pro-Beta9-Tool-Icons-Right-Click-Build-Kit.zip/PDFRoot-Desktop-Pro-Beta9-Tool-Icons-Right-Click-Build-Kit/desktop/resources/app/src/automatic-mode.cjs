const fs = require("node:fs");
const path = require("node:path");

const IMAGE_EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".webp"]);
const JPG_EXTENSIONS = new Set([".jpg", ".jpeg"]);
const PNG_EXTENSIONS = new Set([".png"]);
const PDF_EXTENSIONS = new Set([".pdf"]);
const WORD_EXTENSIONS = new Set([".doc", ".docx"]);
const EXCEL_EXTENSIONS = new Set([".xls", ".xlsx"]);
const POWERPOINT_EXTENSIONS = new Set([".pptx"]);

function autoTool(config) {
  return Object.freeze({
    minimumFiles: 1,
    maximumFiles: undefined,
    beforeActionTexts: [],
    ...config,
    sectionIds: Object.freeze([...(config.sectionIds || [config.sectionId])].filter(Boolean)),
    actionTexts: Object.freeze([...(config.actionTexts || [])]),
    beforeActionTexts: Object.freeze([...(config.beforeActionTexts || [])]),
  });
}

const automaticTools = Object.freeze({
  "jpg-to-pdf": autoTool({
    label: "JPG / Image to PDF",
    sectionId: "jpg-to-pdf-tool",
    actionTexts: ["Convert to PDF"],
    downloadText: "Download PDF",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP image",
  }),
  "png-to-pdf": autoTool({
    label: "PNG to PDF",
    sectionId: "png-to-pdf-tool",
    actionTexts: ["Convert to PDF"],
    downloadText: "Download PDF",
    extensions: PNG_EXTENSIONS,
    fileLabel: "PNG image",
  }),
  "merge-pdf": autoTool({
    label: "Merge PDF",
    sectionId: "merge-pdf-tool",
    actionTexts: ["Merge PDF"],
    downloadText: "Download PDF",
    extensions: PDF_EXTENSIONS,
    fileLabel: "PDF",
    minimumFiles: 2,
  }),
  "compress-pdf": autoTool({
    label: "Compress PDF",
    sectionId: "compress-pdf-tool",
    actionTexts: ["Compress PDF"],
    downloadText: "Download PDF",
    extensions: PDF_EXTENSIONS,
    fileLabel: "PDF",
    autoDescription: "choose Normal, Low, or Heavy compression",
  }),
  "pdf-to-jpg": autoTool({
    label: "PDF to JPG",
    sectionId: "pdf-to-jpg-tool",
    actionTexts: ["Convert to JPG"],
    downloadText: "Download ZIP",
    extensions: PDF_EXTENSIONS,
    fileLabel: "PDF",
    autoDescription: "fast JPG pages saved beside the PDF",
  }),
  "pdf-to-word": autoTool({
    label: "PDF to Word",
    sectionId: "pdf-to-word-tool",
    actionTexts: ["Convert to Word"],
    downloadText: "Download Word",
    extensions: PDF_EXTENSIONS,
    fileLabel: "PDF",
  }),
  "pdf-to-excel": autoTool({
    label: "PDF to Excel",
    sectionId: "pdf-to-excel-tool",
    actionTexts: ["Convert to Excel"],
    downloadText: "Download Excel",
    extensions: PDF_EXTENSIONS,
    fileLabel: "PDF",
  }),
  "word-to-pdf": autoTool({
    label: "Word to PDF",
    sectionId: "word-to-pdf-tool",
    actionTexts: ["Convert to PDF"],
    downloadText: "Download PDF",
    extensions: WORD_EXTENSIONS,
    fileLabel: "DOC or DOCX file",
    maximumFiles: 1,
  }),
  "excel-to-pdf": autoTool({
    label: "Excel to PDF",
    sectionId: "excel-to-pdf-tool",
    actionTexts: ["Convert to PDF"],
    downloadText: "Download PDF",
    extensions: EXCEL_EXTENSIONS,
    fileLabel: "XLS or XLSX file",
  }),
  "powerpoint-to-pdf": autoTool({
    label: "PowerPoint to PDF",
    sectionId: "powerpoint-to-pdf-tool",
    actionTexts: ["Convert to PDF"],
    downloadText: "Download PDF",
    extensions: POWERPOINT_EXTENSIONS,
    fileLabel: "PPTX file",
  }),
  "jpg-to-png": autoTool({
    label: "JPG to PNG",
    sectionId: "jpg-to-png-tool",
    actionTexts: ["Convert to PNG"],
    downloadText: "Download PNG",
    extensions: JPG_EXTENSIONS,
    fileLabel: "JPG or JPEG image",
  }),
  "png-to-jpg": autoTool({
    label: "PNG to JPG",
    sectionId: "png-to-jpg-tool",
    actionTexts: ["Convert to JPG"],
    downloadText: "Download JPG",
    extensions: PNG_EXTENSIONS,
    fileLabel: "PNG image",
  }),
  "compress-image": autoTool({
    label: "Compress Image",
    sectionId: "compress-image-tool",
    actionTexts: ["Compress Image"],
    downloadText: "Download image",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP image",
    autoDescription: "Medium compression default",
  }),
  "image-compressor-for-government-forms": autoTool({
    label: "Government Form Image Compressor",
    sectionId: "compress-image-tool",
    sectionIds: ["compress-image-tool", "government-image-compressor-tool"],
    actionTexts: ["Compress Image"],
    downloadText: "Download image",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP image",
    autoDescription: "Medium compression default",
  }),
  "resize-image-to-exact-kb": autoTool({
    label: "Exact KB Image",
    sectionId: "resize-tool",
    actionTexts: ["Resize Image Now"],
    downloadText: "Download image",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP image",
    autoDescription: "enter a target size in KB",
  }),
  "signature-resize-tool": autoTool({
    label: "Signature Resize",
    sectionId: "signature-resize-tool",
    actionTexts: ["Resize Signature Now", "Resize Now"],
    downloadText: "Download Signature",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP signature image",
    autoDescription: "140 × 60 px, 20 KB default",
  }),
  "ojas-photo-resize": autoTool({
    label: "OJAS Photo Resize",
    sectionId: "ojas-photo-signature-tool",
    actionTexts: ["Create JPG"],
    downloadText: "Download JPG",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP photo",
    autoDescription: "photo with selected date (today by default)",
  }),
  "gpsc-photo-resize": autoTool({
    label: "GPSC Photo Resize",
    sectionId: "gpsc-photo-resize-tool",
    actionTexts: ["Create JPG", "Resize Now"],
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP photo",
    autoDescription: "photo with selected date (today by default)",
  }),
  "ssc-photo-resize": autoTool({
    label: "SSC Photo / Signature Resize",
    sectionId: "ssc-photo-resize-tool",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP image",
    autoDescription: "choose Photo or Signature",
  }),
  "rrb-signature-resize": autoTool({
    label: "RRB Signature Resize",
    sectionId: "rrb-signature-resize-tool",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP signature",
    autoDescription: "140 × 60 px JPEG",
  }),
  "ibps-photo-resize": autoTool({
    label: "IBPS Image Resize",
    sectionId: "ibps-photo-resize-tool",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP image",
    autoDescription: "choose Photo, Signature, Thumb or Declaration",
  }),
  "upsc-photo-resize": autoTool({
    label: "UPSC Photo / Signature Resize",
    sectionId: "upsc-photo-resize-tool",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP image",
    autoDescription: "choose Photo or Signature",
  }),
  "front-back-card-merge": autoTool({
    label: "Front & Back Card Merge",
    sectionId: "front-back-card-merge-tool",
    actionTexts: ["Merge Card"],
    beforeActionTexts: ["Top & Bottom"],
    downloadText: "Download image",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP image",
    minimumFiles: 2,
    maximumFiles: 2,
    autoDescription: "Front on top, back below",
  }),
  "crop-image": autoTool({
    label: "Crop Image",
    sectionId: "crop-image-tool",
    actionTexts: ["Crop Image"],
    downloadText: "Download image",
    extensions: IMAGE_EXTENSIONS,
    fileLabel: "JPG, PNG or WebP image",
    autoDescription: "Preview, crop and replace the selected image",
  }),
});

function extensionOf(filePath) {
  return path.extname(String(filePath || "")).toLowerCase();
}

function selectionCountMessage(tool) {
  if (tool.maximumFiles === 1) return "Select one " + tool.fileLabel + " in File Explorer, then press the shortcut again.";
  if (tool.minimumFiles > 1) return "Select at least " + tool.minimumFiles + " " + tool.fileLabel + " files in File Explorer, then press the shortcut again.";
  return "Select a " + tool.fileLabel + " file in File Explorer, then press the shortcut again.";
}

function validateAutomaticSelection(slug, selectedFiles = []) {
  const tool = automaticTools[slug];
  if (!tool) return { ok: false, files: [], message: "This shortcut needs Normal Mode because it requires your settings or editing." };

  const requested = Array.isArray(selectedFiles) ? selectedFiles : [];
  const seen = new Set();
  const validFiles = [];
  const invalidFiles = [];

  for (const filePath of requested) {
    if (typeof filePath !== "string" || seen.has(filePath)) continue;
    seen.add(filePath);

    if (!fs.existsSync(filePath) || !tool.extensions.has(extensionOf(filePath))) {
      invalidFiles.push(filePath);
      continue;
    }
    validFiles.push(filePath);
  }

  if (invalidFiles.length) {
    return {
      ok: false,
      files: validFiles,
      message: tool.label + " accepts only " + tool.fileLabel + " files. Select only those files in File Explorer and try again.",
    };
  }

  if (validFiles.length < tool.minimumFiles) {
    return { ok: false, files: validFiles, message: selectionCountMessage(tool) };
  }

  if (tool.maximumFiles && validFiles.length > tool.maximumFiles) {
    return {
      ok: false,
      files: validFiles,
      message: tool.label + " uses exactly " + tool.maximumFiles + " files. Select only the front and back images, then press the shortcut again.",
    };
  }

  return { ok: true, files: validFiles, tool };
}

function nextAvailableOutputPath(directory, suggestedFileName, exists = fs.existsSync) {
  const safeName = path.basename(suggestedFileName || "PDFRoot-output");
  const parsed = path.parse(safeName);
  const base = parsed.name || "PDFRoot-output";
  const extension = parsed.ext || "";
  let candidate = path.join(directory, safeName);
  let number = 1;

  while (exists(candidate)) {
    candidate = path.join(directory, base + " (" + number + ")" + extension);
    number += 1;
  }

  return candidate;
}

module.exports = {
  automaticTools,
  validateAutomaticSelection,
  nextAvailableOutputPath,
  extensionOf,
};
