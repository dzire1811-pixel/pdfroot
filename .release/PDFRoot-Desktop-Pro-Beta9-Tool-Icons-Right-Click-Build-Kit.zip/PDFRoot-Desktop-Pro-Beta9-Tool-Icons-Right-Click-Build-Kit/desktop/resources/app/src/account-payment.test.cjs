const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { generateKeyPairSync } = require("node:crypto");
const { AccountClient } = require("./account-client.cjs");
const { LicenseStore, createLicenseCode } = require("./license.cjs");
const { PaymentClient } = require("./payment-client.cjs");

test("account login errors from Preview show a readable message", async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "pdfroot-account-error-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const client = new AccountClient({ baseUrl: "https://pdfroot.example", userDataPath: dir, deviceId: "A".repeat(32),
    fetchImpl: async () => ({ ok: false, status: 401, json: async () => ({ error: { code: "authentication_required", message: "Preview access is required." } }) }) });
  await assert.rejects(client.sendCode("buyer@example.com"), { message: "Preview access is required." });
});

test("Google sign-in keeps the verified profile name for direct checkout", async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "pdfroot-google-account-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const expiresAt = new Date(Date.now() + 864e5).toISOString();
  const client = new AccountClient({ baseUrl: "https://pdfroot.example", userDataPath: dir, deviceId: "A".repeat(32),
    fetchImpl: async () => ({ ok: true, status: 200, json: async () => ({
      token: "G".repeat(43), email: "buyer@example.com", name: "Buyer Name", expiresAt,
    }) }) });
  assert.deepEqual(await client.googleSignIn("header.payload.signature", "nonce"),
    { email: "buyer@example.com", name: "Buyer Name", provider: "google" });
  assert.equal(client.session().name, "Buyer Name");
});

test("verified email starts a device-bound 14-day trial that expires exactly on day 14", async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "pdfroot-trial-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const keys = generateKeyPairSync("ed25519");
  const publicKeyPath = path.join(dir, "public.pem");
  fs.writeFileSync(publicKeyPath, keys.publicKey.export({ type: "spki", format: "pem" }));
  const store = new LicenseStore({ userDataPath: dir, publicKeyPath, deviceHash: "A".repeat(32) });
  const trial = createLicenseCode({ version: 1, issuer: "PDFRoot", plan: "trial", source: "verified-email-trial",
    deviceHash: "A".repeat(32), issuedAt: new Date().toISOString(), expiresAt: new Date(Date.now() + 14 * 864e5).toISOString() },
    keys.privateKey);
  const requests = [];
  const account = new AccountClient({ baseUrl: "https://pdfroot.example", userDataPath: dir, deviceId: "A".repeat(32),
    licenseStore: store, fetchImpl: async (url, options) => {
      requests.push({ url, options });
      const result = url.endsWith("/send-code") ? { ok: true } : url.endsWith("/verify-code")
        ? { token: "X".repeat(43), email: "buyer@example.com", expiresAt: new Date(Date.now() + 864e5).toISOString() }
        : { code: trial };
      return { ok: true, json: async () => result };
    } });
  await account.sendCode("buyer@example.com");
  await account.verifyCode("buyer@example.com", "123456");
  const active = await account.startTrial();
  assert.equal(active.payload.plan, "trial");
  assert.equal(requests[2].options.headers.Authorization, "Bearer " + "X".repeat(43));
  const expired = require("./license.cjs").verifyLicenseCode(trial, { publicKeyPem: fs.readFileSync(publicKeyPath, "utf8"),
    deviceHash: "A".repeat(32), now: new Date(active.expiresAt) });
  assert.equal(expired.state, "expired");
});

test("five-minute checkout expires locally only after server says expired, and a late captured payment still activates", async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "pdfroot-timer-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const expiresAt = new Date(Date.now() + 300000).toISOString();
  let paid = false;
  const store = { activate: (code) => ({ ok: true, code }) };
  const account = { session: () => ({ token: "A".repeat(43) }), syncLicense: async () => ({ state: "none" }) };
  const client = new PaymentClient({ baseUrl: "https://pdfroot.example", userDataPath: dir, deviceId: "A".repeat(32),
    accountClient: account, licenseStore: store, fetchImpl: async (url, options) => ({
      ok: true, json: async () => url.endsWith("/v1/checkout")
        ? { checkoutId: "PDR123", token: "T".repeat(43), paymentUrl: "https://rzp.io/i/test", expiresAt, amountPaise: 19900, currency: "INR" }
        : paid ? { state: "paid", code: "signed-code" } : { state: "expired", expiresAt },
    }) });
  assert.equal((await client.checkout("Buyer Name")).expiresAt, expiresAt);
  assert.equal((await client.check()).state, "expired");
  paid = true;
  assert.equal((await client.check()).state, "active");
});
