const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { contextMenuTools } = require("./context-menu.cjs");

const appRoot = path.join(__dirname, "..");
const iconRoot = path.join(appRoot, "resources", "context-icons");

test("every Explorer context command has its own Windows icon", () => {
  const hashes = new Set();

  for (const tool of contextMenuTools) {
    const iconName = tool.slug === "catalog" ? "pdfroot-menu.ico" : `${tool.slug}.ico`;
    const iconPath = path.join(iconRoot, iconName);
    assert.equal(fs.existsSync(iconPath), true, `${iconName} is missing`);

    const bytes = fs.readFileSync(iconPath);
    assert.deepEqual([...bytes.subarray(0, 4)], [0, 0, 1, 0], `${iconName} is not an ICO file`);
    hashes.add(crypto.createHash("sha256").update(bytes).digest("hex"));
  }

  assert.ok(hashes.size >= 30, "context-menu entries must use the shipped tool-specific icon set");
});

test("installer assigns the white-box brand icon and per-tool icons", () => {
  const installer = fs.readFileSync(path.join(appRoot, "resources", "installer.nsh"), "utf8");
  assert.match(installer, /resources\\context-icons\\pdfroot-menu\.ico/);
  assert.match(installer, /resources\\context-icons\\\$\{Slug\}\.ico/);
  assert.doesNotMatch(installer, /PDFRoot Desktop Pro\.exe,0/);
  assert.match(installer, /PDFRootDesktopPro" "Position" "Top"/);
});
