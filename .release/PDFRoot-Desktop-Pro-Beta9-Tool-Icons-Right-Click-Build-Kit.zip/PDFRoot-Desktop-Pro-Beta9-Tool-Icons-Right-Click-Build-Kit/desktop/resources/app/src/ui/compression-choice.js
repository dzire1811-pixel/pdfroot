const count = Math.max(1, Number(new URLSearchParams(window.location.search).get("files")) || 1);
const fileCount = document.querySelector("#file-count");
fileCount.textContent = count === 1
  ? "Choose a compression level. Your PDF stays in the same folder."
  : `Choose a compression level. ${count} PDFs will stay in their original folder.`;

function choose(level) {
  window.pdfrootDesktop.choosePdfCompression(level);
}

document.querySelectorAll("[data-level]").forEach((button) => {
  button.addEventListener("click", () => choose(button.dataset.level));
});
document.querySelector("#close-choice").addEventListener("click", () => choose(""));
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape") choose("");
});
