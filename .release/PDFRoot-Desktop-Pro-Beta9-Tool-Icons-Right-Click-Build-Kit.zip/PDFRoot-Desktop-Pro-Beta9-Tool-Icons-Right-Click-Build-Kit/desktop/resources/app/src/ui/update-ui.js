const updateBanner = document.querySelector("#desktop-update-banner");
const updateTitle = document.querySelector("#desktop-update-title");
const updateStatusText = document.querySelector("#desktop-update-status");
const updateNote = document.querySelector("#desktop-update-note");
const updateCheckButton = document.querySelector("#desktop-update-check");

function displayUpdateStatus(state) {
  const version = state?.available?.version;
  const phase = state?.phase || "idle";
  const active = ["downloading", "ready", "waiting", "installing"].includes(phase);
  if (updateBanner) updateBanner.hidden = !active;
  let message;
  if (phase === "downloading") message = `Downloading version ${version}… ${state.progress || 0}%`;
  else if (phase === "ready") message = `Version ${version} is ready. Installing and reopening PDFRoot…`;
  else if (phase === "waiting") message = `Version ${version} is ready. Finish the open tool; installation will then run automatically.`;
  else if (phase === "installing") message = "Installing the update and reopening PDFRoot…";
  else if (phase === "checking") message = "Checking for updates…";
  else if (phase === "error") message = state.error || "Automatic update unavailable. Will retry.";
  else if (phase === "idle") message = "Automatic updates are enabled for installed Windows versions.";
  else message = `You're up to date (version ${state?.currentVersion || "unknown"}).`;
  if (updateTitle && active) updateTitle.textContent = message;
  if (updateNote && active) updateNote.textContent = "Your plan and shortcuts stay on this computer.";
  if (updateStatusText) updateStatusText.textContent = message;
}

window.pdfrootDesktop.onUpdateStatus(displayUpdateStatus);
window.pdfrootDesktop.updateStatus().then(displayUpdateStatus).catch(() => {});

if (updateCheckButton) updateCheckButton.addEventListener("click", async () => {
  updateCheckButton.disabled = true;
  if (updateStatusText) updateStatusText.textContent = "Checking for updates…";
  try { displayUpdateStatus(await window.pdfrootDesktop.checkUpdate()); }
  catch { if (updateStatusText) updateStatusText.textContent = "Could not check for updates. Try again."; }
  finally { updateCheckButton.disabled = false; }
});
