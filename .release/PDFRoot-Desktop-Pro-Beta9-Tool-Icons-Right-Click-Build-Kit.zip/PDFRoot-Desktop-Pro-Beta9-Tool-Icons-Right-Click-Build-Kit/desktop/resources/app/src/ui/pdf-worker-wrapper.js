import "./map-polyfill.js";
await import("../../node_modules/pdfjs-dist/build/pdf.worker.mjs");
