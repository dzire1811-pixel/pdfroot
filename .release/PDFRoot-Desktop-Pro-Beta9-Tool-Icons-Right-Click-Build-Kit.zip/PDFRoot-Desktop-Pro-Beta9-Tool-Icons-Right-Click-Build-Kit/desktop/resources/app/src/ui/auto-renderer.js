import * as pdfjsLib from "../../node_modules/pdfjs-dist/build/pdf.mjs";

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL("./pdf-worker-wrapper.js", import.meta.url).href;

function base64ToBytes(base64) {
  const binary = atob(base64);
  const data = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) data[index] = binary.charCodeAt(index);
  return data;
}

function dataUrlBase64(dataUrl) {
  return dataUrl.slice(dataUrl.indexOf(",") + 1);
}

function clampNumber(value, fallback, minimum, maximum) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return fallback;
  return Math.max(minimum, Math.min(maximum, numeric));
}

async function renderPdfToJpg({ base64, scale = 1.2, quality = 0.84, maximumSide = 2200 }) {
  const safeScale = clampNumber(scale, 1.2, 0.6, 2.5);
  const safeQuality = clampNumber(quality, 0.84, 0.4, 0.95);
  const safeMaximumSide = Math.round(clampNumber(maximumSide, 2200, 900, 3000));
  const loadingTask = pdfjsLib.getDocument({
    data: base64ToBytes(base64),
    disableAutoFetch: true,
    disableRange: true,
  });
  const pdf = await loadingTask.promise;
  const pages = [];

  try {
    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
      const page = await pdf.getPage(pageNumber);
      let viewport = page.getViewport({ scale: safeScale });
      if (Math.max(viewport.width, viewport.height) > safeMaximumSide) {
        viewport = page.getViewport({ scale: safeScale * (safeMaximumSide / Math.max(viewport.width, viewport.height)) });
      }
      const canvas = document.createElement("canvas");
      canvas.width = Math.ceil(viewport.width);
      canvas.height = Math.ceil(viewport.height);
      const context = canvas.getContext("2d", { alpha: false });
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: context, viewport }).promise;
      pages.push(dataUrlBase64(canvas.toDataURL("image/jpeg", safeQuality)));
      canvas.width = 0;
      canvas.height = 0;
      page.cleanup();
    }
    return pages;
  } finally {
    // PDFDocumentProxy has no destroy() method in pdfjs-dist 6. The loading
    // task owns the worker and its destroy() method releases PDF resources.
    try { await loadingTask.destroy(); } catch { /* Keep the render result. */ }
  }
}

window.pdfrootLocalRenderer = { renderPdfToJpg };
