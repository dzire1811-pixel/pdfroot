const toolSections = document.querySelector("#tool-sections");
const catalogScroller = document.querySelector("#catalog-scroll");
const searchInput = document.querySelector("#tool-search");
const shortcutContainer = document.querySelector("#shortcut-list");
const shortcutPopover = document.querySelector("#shortcuts");
const planStatus = document.querySelector("#plan-status");
const startupToggle = document.querySelector("#startup-toggle");
const modeSupported = document.querySelector("#mode-supported");
const modeToggle = document.querySelector("#mode-toggle");
const toolCount = document.querySelector("#tool-count");
const shortcutHealthCount = document.querySelector("#shortcut-health-count");
const shortcutHealthNote = document.querySelector("#shortcut-health-note");
const shortcutActivity = document.querySelector("#shortcut-activity");
const refreshShortcutsButton = document.querySelector("#refresh-shortcuts");

let allTools = [];
let allShortcuts = [];
let processingMode = "normal";
let showcaseTools = [];
let showcasePage = 0;
let featureTab = "popular";
let activeToolCategory = "all";
let introTimer;
let introTarget = null;
const showcasePageSize = 6;
const featuredSlugs = ["merge-pdf", "jpg-to-pdf", "compress-pdf", "resize-image-to-exact-kb", "crop-image", "pdf-to-jpg"];

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character]));
}

function colorStyleFor(slug) {
  // 47 is coprime with 360, so catalog positions get distinct,
  // restrained color hue while keeping the card readable.
  const index = Math.max(0, allTools.findIndex((tool) => tool.slug === slug));
  const hue = (250 + index * 47) % 360;
  return `--card-bg:hsl(${hue} 90% 99%);--card-border:hsl(${hue} 58% 88%);--card-hover:hsl(${hue} 52% 72%);`;
}

function renderShowcase() {
  const pages = Math.max(1, Math.ceil(showcaseTools.length / showcasePageSize));
  showcasePage = Math.min(Math.max(showcasePage, 0), pages - 1);
  const palette = ["rose", "blue", "green", "amber", "purple", "pink"];
  document.querySelector("#showcase-grid").innerHTML = showcaseTools
    .slice(showcasePage * showcasePageSize, (showcasePage + 1) * showcasePageSize)
    .map((tool, index) => `<button type="button" class="showcase-tile tile-${palette[index]}" data-showcase-tool="${escapeHtml(tool.slug)}" title="Open ${escapeHtml(tool.name)}"><img src="tool-icons/${escapeHtml(tool.slug)}.svg" alt="" /><span>${escapeHtml(tool.name)}</span><small>${escapeHtml(tool.description)}</small><i aria-hidden="true">→</i></button>`)
    .join("");
  document.querySelector("#showcase-page-label").textContent = `${String(showcasePage + 1).padStart(2, "0")} / ${String(pages).padStart(2, "0")}`;
  document.querySelector("#showcase-prev").disabled = showcasePage === 0;
  document.querySelector("#showcase-next").disabled = showcasePage >= pages - 1;
  document.querySelectorAll("[data-showcase-tool]").forEach((button) => {
    button.addEventListener("click", () => window.pdfrootDesktop.openTool(button.dataset.showcaseTool));
  });
}

function setFeatureTab(tab) {
  featureTab = tab;
  showcasePage = 0;
  showcaseTools = tab === "popular"
    ? [...featuredSlugs.map((slug) => allTools.find((tool) => tool.slug === slug)).filter(Boolean),
      ...allTools.filter((tool) => !featuredSlugs.includes(tool.slug))]
    : allTools.filter((tool) => tool.category === tab);
  document.querySelectorAll("[data-feature-tab]").forEach((button) => {
    const active = button.dataset.featureTab === tab;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  renderShowcase();
}

function selectNavigation(section) {
  shortcutPopover.hidden = section !== "shortcuts";
  document.querySelectorAll("[data-nav]").forEach((button) => {
    const active = button.dataset.nav === section;
    button.classList.toggle("active", active);
    if (active) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  });
  document.querySelectorAll("[data-device-nav]").forEach((button) => {
    const active = button.dataset.deviceNav === section;
    button.classList.toggle("active", active);
    if (active) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  });
  const labels = { home: "Home", all: "All Tools", pdf: "PDF Tools", image: "Image Tools", government: "Government Tools", shortcuts: "Shortcuts", settings: "Settings" };
  document.querySelector("#current-section-title").textContent = labels[section] || "Home";
  if (section === "home") {
    introTarget = null;
    activeToolCategory = "all";
    renderTools();
    catalogScroller.scrollTo({ top: 0 });
    document.body.classList.remove("catalog-active");
    document.body.classList.add("intro-active");
    clearTimeout(introTimer);
    introTimer = setTimeout(() => selectNavigation("all"), 5000);
    return;
  }
  introTarget = section;
  clearTimeout(introTimer);
  document.body.classList.remove("intro-active");
  document.body.classList.add("catalog-active");
  if (["all", "pdf", "image", "government"].includes(section)) {
    activeToolCategory = section;
    renderTools();
    document.querySelector("#tool-directory").scrollIntoView({ behavior: "smooth", block: "start" });
    return;
  }
  if (section === "shortcuts") return;
  document.querySelector("#workspace-account").scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderTools() {
  const query = searchInput.value.trim().toLowerCase();
  const visibleTools = allTools.filter((tool) =>
    (activeToolCategory === "all" || tool.category.toLowerCase() === activeToolCategory)
    && `${tool.name} ${tool.description} ${tool.category}`.toLowerCase().includes(query));
  toolCount.textContent = `${visibleTools.length} ${visibleTools.length === 1 ? "tool" : "tools"} found`;
  if (!visibleTools.length) {
    toolSections.innerHTML = '<section class="panel empty">No matching tool found. Try a different name, task or file type.</section>';
    return;
  }

  const categories = ["PDF", "Image", "Government"];
  toolSections.innerHTML = categories.map((category) => {
    const categoryTools = visibleTools.filter((tool) => tool.category === category);
    if (!categoryTools.length) return "";
    const cards = categoryTools.map((tool) => {
      return `<button class="tool-card" style="${colorStyleFor(tool.slug)}" type="button" data-tool="${escapeHtml(tool.slug)}">
        <span class="tool-card-top"><span class="tool-icon"><img src="tool-icons/${escapeHtml(tool.slug)}.svg" alt="" /></span><span class="tool-card-arrow" aria-hidden="true">→</span></span>
        <h3>${escapeHtml(tool.name)}</h3><p>${escapeHtml(tool.description)}</p>
      </button>`;
    }).join("");
    return `<section><div class="section-heading"><h2>${escapeHtml(category)} tools</h2><span>${categoryTools.length} tools</span></div><div class="tools-grid">${cards}</div></section>`;
  }).join("");

  toolSections.querySelectorAll("[data-tool]").forEach((button) => {
    button.addEventListener("click", () => window.pdfrootDesktop.openTool(button.dataset.tool));
  });
}

function renderShortcuts() {
  const ready = allShortcuts.filter((shortcut) => shortcut.registered).length;
  const unavailable = allShortcuts.length - ready;
  shortcutHealthCount.textContent = `${ready} of ${allShortcuts.length} global shortcut keys ready`;
  shortcutHealthCount.className = `shortcut-health-count ${unavailable ? "warning" : "ready"}`;
  shortcutHealthNote.textContent = unavailable
    ? "Some primary keys are in use by Windows or another app. Available alternate keys are shown below."
    : "PDFRoot stays ready in the tray while you work in File Explorer.";
  shortcutContainer.innerHTML = allShortcuts.map((shortcut, index) => `
    <span class="shortcut-chip ${shortcut.auto ? "auto" : ""} ${shortcut.registered ? "" : "unavailable"} ${shortcut.usedFallback ? "fallback" : ""}" style="--shortcut-hue:${(index * 47 + 190) % 360}" title="${shortcut.usedFallback ? "Primary key was busy; use this fallback key." : ""}"><b>${escapeHtml(shortcut.effectiveDisplay || shortcut.display)}</b> <i>·</i> ${escapeHtml(shortcut.label)}${(shortcut.alternateDisplays || []).length ? `<small>Backup: ${escapeHtml(shortcut.alternateDisplays.join(" / "))}</small>` : ""}</span>
  `).join("");
}

function renderShortcutActivity(activity) {
  if (!activity || !activity.display) return;
  shortcutActivity.textContent = `Last key: ${activity.display} — ${activity.message || activity.label || "detected"}`;
  shortcutActivity.className = `shortcut-activity ${activity.phase === "complete" ? "success" : activity.phase === "failed" ? "error" : "active"}`;
}

function renderProcessingMode(modeInfo) {
  processingMode = modeInfo.mode === "auto" ? "auto" : "normal";
  const auto = processingMode === "auto";
  document.body.dataset.processingMode = processingMode;
  modeSupported.textContent = auto
    ? `${modeInfo.automaticShortcutCount ?? modeInfo.automaticTools?.length ?? 0} Auto shortcuts are ready`
    : "Normal Mode";
  modeToggle.classList.toggle("auto", auto);
  modeToggle.setAttribute("aria-pressed", String(auto));
  modeToggle.querySelector(".mode-toggle-state").textContent = auto ? "Auto" : "Normal";
}

async function initialise() {
  const [status, tools, shortcuts, startup, modeInfo, activity] = await Promise.all([
    window.pdfrootDesktop.licenseStatus(),
    window.pdfrootDesktop.tools(),
    window.pdfrootDesktop.shortcuts(),
    window.pdfrootDesktop.startup(),
    window.pdfrootDesktop.processingMode(),
    window.pdfrootDesktop.shortcutActivity(),
  ]);

  if (!status.ok) return window.pdfrootDesktop.openCatalog();
  allTools = tools;
  allShortcuts = shortcuts;
  document.querySelector("#hero-tool-count").textContent = `${tools.length} tools`;
  document.querySelector("#highlight-tool-count").textContent = `${tools.length} tools`;
  document.querySelector("#nav-tool-count").textContent = String(tools.length);
  setFeatureTab(featureTab);
  planStatus.textContent = status.state === "grace" ? "Renewal grace period" : status.payload?.plan === "trial" ? "Free trial active" : "Monthly plan active";
  planStatus.className = `status-pill ${status.state === "grace" ? "warn" : ""}`.trim();
  window.pdfrootDesktop.accountSummary().then((summary) => {
    if (summary.error) {
      document.querySelector("#workspace-plan").textContent = status.payload?.plan === "trial" ? "Free Trial" : "PDFRoot Shortcut Pro";
      document.querySelector("#workspace-status").textContent = "Active";
      return;
    }
    document.querySelector("#workspace-email").textContent = summary.email;
    document.querySelector("#workspace-plan").textContent = summary.plan || "Choose a plan";
    document.querySelector("#workspace-status").textContent = summary.status;
    document.querySelector("#workspace-expiry").textContent = summary.expiresAt
      ? new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Kolkata" }).format(new Date(summary.expiresAt)) : "—";
    document.querySelector("#workspace-remaining").textContent = summary.remainingDays == null ? "—" : `${summary.remainingDays} days`;
    if (summary.status === "active") planStatus.textContent = summary.planType === "trial"
      ? `Trial · ${summary.remainingDays} days` : `${summary.plan} · Active`;
  }).catch(() => {});
  startupToggle.classList.toggle("on", Boolean(startup));
  startupToggle.setAttribute("aria-pressed", String(Boolean(startup)));
  renderProcessingMode(modeInfo);
  renderShortcuts();
  renderShortcutActivity(activity);
  renderTools();
  selectNavigation(introTarget || "home");
}

searchInput.addEventListener("input", renderTools);
planStatus.addEventListener("click", () => selectNavigation("settings"));
document.querySelectorAll("[data-nav]").forEach((button) => {
  button.addEventListener("click", () => selectNavigation(button.dataset.nav));
});
document.querySelectorAll("[data-device-nav]").forEach((button) => {
  button.addEventListener("click", () => selectNavigation(button.dataset.deviceNav));
});
document.querySelectorAll("[data-feature-tab]").forEach((button) => {
  button.addEventListener("click", () => setFeatureTab(button.dataset.featureTab));
});
document.querySelector("#hero-explore").addEventListener("click", () => selectNavigation("all"));
document.querySelector("#go-to-all-tools").addEventListener("click", () => selectNavigation("all"));
document.querySelector("#hero-shortcuts").addEventListener("click", () => selectNavigation("shortcuts"));
document.querySelector("#close-shortcuts").addEventListener("click", () => {
  shortcutPopover.hidden = true;
  document.querySelectorAll('[data-nav="shortcuts"], [data-device-nav="shortcuts"]').forEach((button) => {
    button.classList.remove("active");
    button.removeAttribute("aria-current");
  });
});
document.querySelector("#showcase-prev").addEventListener("click", () => { showcasePage -= 1; renderShowcase(); });
document.querySelector("#showcase-next").addEventListener("click", () => { showcasePage += 1; renderShowcase(); });
startupToggle.addEventListener("click", async () => {
  const nextValue = !startupToggle.classList.contains("on");
  const enabled = await window.pdfrootDesktop.setStartup(nextValue);
  startupToggle.classList.toggle("on", enabled);
  startupToggle.setAttribute("aria-pressed", String(enabled));
});

refreshShortcutsButton.addEventListener("click", async () => {
  refreshShortcutsButton.disabled = true;
  refreshShortcutsButton.textContent = "Checking…";
  try {
    const result = await window.pdfrootDesktop.refreshShortcuts();
    allShortcuts = result.shortcuts;
    renderShortcuts();
    renderTools();
  } finally {
    refreshShortcutsButton.disabled = false;
    refreshShortcutsButton.textContent = "Refresh shortcut keys";
  }
});

window.pdfrootDesktop.onShortcutsUpdated((shortcuts) => {
  allShortcuts = Array.isArray(shortcuts) ? shortcuts : [];
  renderShortcuts();
});

window.pdfrootDesktop.onShortcutActivity((activity) => renderShortcutActivity(activity));

modeToggle.addEventListener("click", async () => {
  const result = await window.pdfrootDesktop.setProcessingMode(processingMode === "auto" ? "normal" : "auto");
  renderProcessingMode(result);
});

initialise();
