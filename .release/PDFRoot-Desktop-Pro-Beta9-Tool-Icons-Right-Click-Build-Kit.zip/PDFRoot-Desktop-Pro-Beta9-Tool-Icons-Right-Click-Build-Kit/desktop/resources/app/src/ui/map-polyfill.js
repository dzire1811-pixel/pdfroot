// pdfjs-dist 6 uses Map.getOrInsertComputed, which is unavailable in the
// Chromium version bundled by some PDFRoot Desktop Pro builds.
if (typeof Map.prototype.getOrInsertComputed !== "function") {
  Object.defineProperty(Map.prototype, "getOrInsertComputed", {
    configurable: true,
    writable: true,
    value(key, callback) {
      if (this.has(key)) return this.get(key);
      const value = callback(key);
      this.set(key, value);
      return value;
    },
  });
}
