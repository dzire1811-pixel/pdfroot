const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

const GRACE_DAYS = 3;

function stableStringify(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`;
}

function toBase64Url(value) {
  return Buffer.from(value).toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function fromBase64Url(value) {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - (value.length % 4)) % 4);
  return Buffer.from(padded, "base64");
}

function decodeLicenseCode(code) {
  const parts = String(code || "").trim().split(".");
  if (parts.length !== 3 || parts[0] !== "PDR1") throw new Error("This is not a valid PDFRoot activation code.");

  const payload = JSON.parse(fromBase64Url(parts[1]).toString("utf8"));
  const signature = fromBase64Url(parts[2]);
  if (!payload || typeof payload !== "object" || Array.isArray(payload) || !signature.length) {
    throw new Error("This activation code is incomplete.");
  }

  return { payload, signature };
}

function createLicenseCode(payload, privateKeyPem) {
  const signature = crypto.sign(null, Buffer.from(stableStringify(payload)), privateKeyPem);
  return `PDR1.${toBase64Url(stableStringify(payload))}.${toBase64Url(signature)}`;
}

function readPublicKey(publicKeyPath) {
  try {
    return fs.readFileSync(publicKeyPath, "utf8");
  } catch {
    return null;
  }
}

function splitPublicKeys(publicKeyPem) {
  return String(publicKeyPem || "").match(/-----BEGIN PUBLIC KEY-----[\s\S]*?-----END PUBLIC KEY-----/g) || [];
}

function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Unknown" : date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function verifyLicenseCode(code, { publicKeyPem, deviceHash, now = new Date() }) {
  if (!publicKeyPem) {
    return { ok: false, state: "issuer-not-configured", message: "The seller build is not configured with a license public key." };
  }

  try {
    const { payload, signature } = decodeLicenseCode(code);
    const verified = splitPublicKeys(publicKeyPem).some((key) => {
      try { return crypto.verify(null, Buffer.from(stableStringify(payload)), key, signature); }
      catch { return false; }
    });
    if (!verified) return { ok: false, state: "invalid", message: "This activation code could not be verified." };
    if (payload.version !== 1 || payload.issuer !== "PDFRoot" || !["monthly", "trial"].includes(payload.plan)) {
      return { ok: false, state: "invalid", message: "This activation code is not for PDFRoot Desktop Pro." };
    }
    if (!payload.deviceHash || payload.deviceHash !== deviceHash) {
      return { ok: false, state: "device-mismatch", message: "This code belongs to a different computer." };
    }

    const issuedAt = new Date(payload.issuedAt);
    const expiresAt = new Date(payload.expiresAt);
    if (Number.isNaN(issuedAt.getTime()) || Number.isNaN(expiresAt.getTime()) || expiresAt <= issuedAt) {
      return { ok: false, state: "invalid", message: "This activation code has an invalid renewal date." };
    }

    // Payment-backed plans stop at their paid expiry. Older manual codes retain
    // their original grace period so an upgrade does not revoke them early.
    const graceDays = payload.source === "razorpay-payment" || payload.plan === "trial" ? 0 : GRACE_DAYS;
    const graceEndsAt = new Date(expiresAt.getTime() + graceDays * 24 * 60 * 60 * 1000);
    const nowTime = now.getTime();
    if (graceDays === 0 ? nowTime >= expiresAt.getTime() : nowTime > graceEndsAt.getTime()) {
      return {
        ok: false,
        state: "expired",
        message: payload.plan === "trial" ? `Your free trial ended on ${formatDate(expiresAt)}. Choose PDFRoot Shortcut Pro to continue.` : `Your plan ended on ${formatDate(expiresAt)}. Enter the latest renewal code to continue.`,
        payload,
        expiresAt: expiresAt.toISOString(),
        graceEndsAt: graceEndsAt.toISOString(),
      };
    }

    const state = nowTime > expiresAt.getTime() ? "grace" : "active";
    return {
      ok: true,
      state,
      message: state === "grace" ? `Renew your plan by ${formatDate(graceEndsAt)} to avoid interruption.` : `${payload.plan === "trial" ? "Free trial" : "Plan"} active until ${formatDate(expiresAt)}.`,
      payload,
      expiresAt: expiresAt.toISOString(),
      graceEndsAt: graceEndsAt.toISOString(),
    };
  } catch (error) {
    return { ok: false, state: "invalid", message: error instanceof Error ? error.message : "This activation code could not be read." };
  }
}

class LicenseStore {
  constructor({ userDataPath, publicKeyPath, deviceHash }) {
    this.licensePath = path.join(userDataPath, "license.json");
    this.publicKeyPath = publicKeyPath;
    this.deviceHash = deviceHash;
  }

  getStatus() {
    if (!fs.existsSync(this.licensePath)) {
      return { ok: false, state: "needs-activation", message: "Choose a 14-day free trial or PDFRoot Shortcut Pro." };
    }

    try {
      const stored = JSON.parse(fs.readFileSync(this.licensePath, "utf8"));
      return verifyLicenseCode(stored.code, {
        publicKeyPem: readPublicKey(this.publicKeyPath),
        deviceHash: this.deviceHash,
      });
    } catch {
      return { ok: false, state: "invalid", message: "Your saved license could not be read. Please enter the latest activation code." };
    }
  }

  activate(code) {
    const status = verifyLicenseCode(code, {
      publicKeyPem: readPublicKey(this.publicKeyPath),
      deviceHash: this.deviceHash,
    });

    if (!status.ok) return status;

    const previous = this.getStatus();
    if (previous.ok && new Date(previous.expiresAt) > new Date(status.expiresAt)) {
      return { ...previous, message: "Your newer license is already active." };
    }

    const tempPath = `${this.licensePath}.new`;
    fs.writeFileSync(tempPath, JSON.stringify({ code: String(code).trim(), activatedAt: new Date().toISOString() }, null, 2), { mode: 0o600 });
    fs.renameSync(tempPath, this.licensePath);
    return status;
  }
}

module.exports = {
  GRACE_DAYS,
  LicenseStore,
  createLicenseCode,
  decodeLicenseCode,
  stableStringify,
  verifyLicenseCode,
};
