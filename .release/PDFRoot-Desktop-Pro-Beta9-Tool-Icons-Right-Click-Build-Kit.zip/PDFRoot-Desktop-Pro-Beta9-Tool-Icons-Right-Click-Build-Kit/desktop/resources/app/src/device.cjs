const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

function createDeviceIdentity(userDataPath) {
  const fallbackPath = path.join(userDataPath, "device-id.txt");

  try {
    // node-machine-id produces an OS-derived ID on Windows. The hash is never sent to PDFRoot by this desktop core.
    const { machineIdSync } = require("node-machine-id");
    const machineId = machineIdSync(true);
    if (machineId) return crypto.createHash("sha256").update(`pdfroot-desktop:${machineId}`).digest("hex").slice(0, 32).toUpperCase();
  } catch {
    // A stable random fallback keeps activation usable on locked-down PCs where Windows does not expose the machine ID.
  }

  if (fs.existsSync(fallbackPath)) return fs.readFileSync(fallbackPath, "utf8").trim();

  const id = crypto.randomBytes(16).toString("hex").toUpperCase();
  fs.writeFileSync(fallbackPath, id, { mode: 0o600 });
  return id;
}

module.exports = { createDeviceIdentity };
