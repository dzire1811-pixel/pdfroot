const fs = require("node:fs");
const path = require("node:path");
const { Jimp, JimpMime } = require("jimp");

async function frontBackPreviews(files) {
  if (!Array.isArray(files) || files.length !== 2) throw new Error("Select exactly two images.");
  return Promise.all(files.map(async (filePath) => {
    const image = await Jimp.read(await fs.promises.readFile(filePath));
    const ratio = Math.min(1, 480 / image.width, 180 / image.height);
    if (ratio < 1) image.resize({ w: Math.max(1, Math.round(image.width * ratio)) });
    const jpeg = await image.getBuffer(JimpMime.jpeg, { quality: 76 });
    return {
      name: path.basename(filePath),
      preview: `data:image/jpeg;base64,${Buffer.from(jpeg).toString("base64")}`,
    };
  }));
}

module.exports = { frontBackPreviews };
