"use strict";
const crypto = require("node:crypto");
const http = require("node:http");

function googleClientId(configPath) {
  try {
    const value = JSON.parse(require("node:fs").readFileSync(configPath, "utf8")).googleClientId;
    return typeof value === "string" && /^[\w-]+\.apps\.googleusercontent\.com$/.test(value) ? value : "";
  } catch { return ""; }
}

async function signInWithGoogle({ clientId, openExternal, exchange, fetchImpl = fetch, timeoutMs = 120000 }) {
  if (!clientId) throw new Error("Google sign-in needs a PDFRoot Google OAuth desktop client ID.");
  const verifier = crypto.randomBytes(48).toString("base64url");
  const challenge = crypto.createHash("sha256").update(verifier).digest("base64url");
  const state = crypto.randomBytes(32).toString("base64url");
  const nonce = crypto.randomBytes(32).toString("base64url");
  let finish;
  const done = new Promise((resolve, reject) => { finish = { resolve, reject }; });
  let settled = false;
  let used = false;
  let timer;
  let redirectUri = "";
  const server = http.createServer(async (request, response) => {
    const url = new URL(request.url, "http://127.0.0.1");
    if (request.method !== "GET" || url.pathname !== "/callback") {
      response.writeHead(404).end(); return;
    }
    if (used || url.searchParams.get("state") !== state) {
      response.writeHead(400, { "Content-Type": "text/plain; charset=utf-8" }).end("Invalid sign-in request."); return;
    }
    used = true;
    response.writeHead(200, { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" })
      .end("Return to PDFRoot Desktop Pro. You may close this tab.");
    try {
      if (url.searchParams.get("error")) throw new Error("Google sign-in was canceled.");
      const code = url.searchParams.get("code");
      if (!code) throw new Error("Google did not return a sign-in code.");
      const tokenResponse = await fetchImpl("https://oauth2.googleapis.com/token", {
        method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ client_id: clientId, code, code_verifier: verifier,
          grant_type: "authorization_code", redirect_uri: redirectUri }),
        signal: AbortSignal.timeout(12000),
      });
      const tokens = await tokenResponse.json();
      if (!tokenResponse.ok || typeof tokens.id_token !== "string") throw new Error("Google could not finish sign-in.");
      const result = await exchange(tokens.id_token, nonce);
      if (!settled) { settled = true; finish.resolve(result); }
    } catch (error) { if (!settled) { settled = true; finish.reject(error); } }
    finally { clearTimeout(timer); server.close(); }
  });
  try {
    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(0, "127.0.0.1", resolve);
    });
    redirectUri = `http://127.0.0.1:${server.address().port}/callback`;
    const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
    for (const [key, value] of Object.entries({ client_id: clientId, redirect_uri: redirectUri,
      response_type: "code", scope: "openid email profile", code_challenge: challenge,
      code_challenge_method: "S256", state, nonce })) url.searchParams.set(key, value);
    timer = setTimeout(() => {
      if (!settled) { settled = true; finish.reject(new Error("Google sign-in timed out. Try again.")); }
      server.close();
    }, timeoutMs);
    await openExternal(url.toString());
    return await done;
  } catch (error) { clearTimeout(timer); server.close(); throw error; }
}

module.exports = { googleClientId, signInWithGoogle };
