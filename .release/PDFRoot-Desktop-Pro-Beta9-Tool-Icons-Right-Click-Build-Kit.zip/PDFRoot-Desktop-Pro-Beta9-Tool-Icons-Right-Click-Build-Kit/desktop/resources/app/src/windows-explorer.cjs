const { spawn } = require("node:child_process");
const fs = require("node:fs");

let selectionWorker;
let selectionWorkerReady = false;
let selectionWorkerBuffer = "";
let selectionRequestId = 0;
const pendingSelections = new Map();

// v0.2.x queried Shell.Application directly. Keep the same COM connection
// alive in Auto Mode so a shortcut does not launch PowerShell and compile
// Add-Type every time the user selects files in Explorer.
const warmSelectionScript = `
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class PdfRootForegroundWindow {
  [DllImport("user32.dll")]
  public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")]
  public static extern IntPtr GetAncestor(IntPtr hWnd, uint gaFlags);
  [DllImport("user32.dll")]
  public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
}
'@
$shell = New-Object -ComObject Shell.Application
[Console]::Out.WriteLine('READY')
while ($null -ne ($requestId = [Console]::In.ReadLine())) {
  try {
    $foreground = [PdfRootForegroundWindow]::GetForegroundWindow()
    $root = [PdfRootForegroundWindow]::GetAncestor($foreground, 2)
    $handles = @($foreground.ToInt64(), $root.ToInt64())
    $windows = @($shell.Windows())
    $window = $windows | Where-Object { $handles -contains $_.HWND } | Select-Object -First 1
    $foregroundPid = [uint32]0
    [void][PdfRootForegroundWindow]::GetWindowThreadProcessId($foreground, [ref]$foregroundPid)
    $foregroundProcess = (Get-Process -Id $foregroundPid -ErrorAction SilentlyContinue).ProcessName
    if ($null -eq $window -and $foregroundProcess -eq 'PDFRoot Desktop Pro') {
      # A PDFRoot editor may have focus while the user's Explorer selection
      # remains in the background. Use it only when the choice is unambiguous.
      $selectedWindows = @($windows | Where-Object {
        try { $_.Document.SelectedItems().Count -gt 0 } catch { $false }
      })
      if ($selectedWindows.Count -eq 1) { $window = $selectedWindows[0] }
    }
    $paths = @()
    if ($null -ne $window) {
      $paths = @($window.Document.SelectedItems() | ForEach-Object { $_.Path } | Where-Object { $_ })
    }
    $result = @{ id = [int]$requestId; paths = $paths } | ConvertTo-Json -Compress -Depth 3
    [Console]::Out.WriteLine($result)
  } catch {
    [Console]::Out.WriteLine('{"id":' + $requestId + ',"paths":[]}')
  }
}
`;

function clearSelectionWorker(child) {
  if (selectionWorker !== child) return;
  selectionWorker = undefined;
  selectionWorkerReady = false;
  selectionWorkerBuffer = "";
  for (const request of pendingSelections.values()) {
    clearTimeout(request.timer);
    request.resolve(null);
  }
  pendingSelections.clear();
}

function handleSelectionWorkerLine(line) {
  if (line === "READY") {
    selectionWorkerReady = true;
    return;
  }
  let response;
  try { response = JSON.parse(line); } catch { return; }
  const request = pendingSelections.get(response.id);
  if (!request) return;
  pendingSelections.delete(response.id);
  clearTimeout(request.timer);
  request.resolve(Array.isArray(response.paths)
    ? response.paths.filter((filePath) => typeof filePath === "string" && fs.existsSync(filePath))
    : []);
}

function startExplorerSelectionService() {
  if (process.platform !== "win32" || selectionWorker) return;
  let child;
  try {
    child = spawn("powershell.exe", [
      "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
      "-Command", warmSelectionScript,
    ], { windowsHide: true, stdio: ["pipe", "pipe", "ignore"] });
  } catch { return; }
  selectionWorker = child;
  child.stdout.setEncoding("utf8");
  child.stdout.on("data", (chunk) => {
    selectionWorkerBuffer += chunk;
    let newline;
    while ((newline = selectionWorkerBuffer.indexOf("\n")) !== -1) {
      const line = selectionWorkerBuffer.slice(0, newline).trim();
      selectionWorkerBuffer = selectionWorkerBuffer.slice(newline + 1);
      handleSelectionWorkerLine(line);
    }
  });
  child.once("error", () => clearSelectionWorker(child));
  child.once("close", () => clearSelectionWorker(child));
}

function stopExplorerSelectionService() {
  if (!selectionWorker) return;
  const child = selectionWorker;
  try { child.stdin.end(); } catch {}
  try { child.kill(); } catch {}
  clearSelectionWorker(child);
}

function parseExplorerPaths(rawOutput, exists = fs.existsSync) {
  if (typeof rawOutput !== "string" || !rawOutput.trim()) return [];
  try {
    const parsed = JSON.parse(rawOutput.trim());
    const paths = Array.isArray(parsed) ? parsed : [parsed];
    return paths.filter((filePath) => typeof filePath === "string" && exists(filePath));
  } catch {
    return [];
  }
}

// File Explorer selection must be captured without freezing Electron’s main
// process. The earlier synchronous PowerShell call could block every hotkey
// for up to 1.8 seconds and made a working shortcut look unresponsive.
function getFocusedExplorerSelection({ timeoutMs = 900 } = {}) {
  if (process.platform !== "win32") return Promise.resolve([]);

  if (selectionWorkerReady && selectionWorker?.stdin?.writable) {
    const id = ++selectionRequestId;
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        pendingSelections.delete(id);
        resolve(null);
      }, Math.max(100, Math.min(800, Number(timeoutMs) || 600)));
      pendingSelections.set(id, { resolve, timer });
      try {
        selectionWorker.stdin.write(`${id}\n`, (error) => {
          if (!error || !pendingSelections.has(id)) return;
          clearTimeout(timer);
          pendingSelections.delete(id);
          resolve(null);
        });
      } catch {
        clearTimeout(timer);
        pendingSelections.delete(id);
        resolve(null);
      }
    }).then((paths) => paths === null ? getFocusedExplorerSelectionCold({ timeoutMs }) : paths);
  }
  return getFocusedExplorerSelectionCold({ timeoutMs });
}

function getFocusedExplorerSelectionCold({ timeoutMs = 900 } = {}) {
  if (process.platform !== "win32") return Promise.resolve([]);

  const script = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class PdfRootForegroundWindow {
  [DllImport("user32.dll")]
  public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")]
  public static extern IntPtr GetAncestor(IntPtr hWnd, uint gaFlags);
  [DllImport("user32.dll")]
  public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
}
'@
$foreground = [PdfRootForegroundWindow]::GetForegroundWindow()
$root = [PdfRootForegroundWindow]::GetAncestor($foreground, 2)
$handles = @($foreground.ToInt64(), $root.ToInt64())
$shell = New-Object -ComObject Shell.Application
$windows = @($shell.Windows())
$window = $windows | Where-Object { $handles -contains $_.HWND } | Select-Object -First 1
 $foregroundPid = [uint32]0
[void][PdfRootForegroundWindow]::GetWindowThreadProcessId($foreground, [ref]$foregroundPid)
$foregroundProcess = (Get-Process -Id $foregroundPid -ErrorAction SilentlyContinue).ProcessName
if ($null -eq $window -and $foregroundProcess -eq 'PDFRoot Desktop Pro') {
  $selectedWindows = @($windows | Where-Object {
    try { $_.Document.SelectedItems().Count -gt 0 } catch { $false }
  })
  if ($selectedWindows.Count -eq 1) { $window = $selectedWindows[0] }
}
if ($null -eq $window) { exit 0 }
$paths = @($window.Document.SelectedItems() | ForEach-Object { $_.Path } | Where-Object { $_ })
if ($paths.Count -gt 0) { $paths | ConvertTo-Json -Compress }
`;

  return new Promise((resolve) => {
    let completed = false;
    let timer;
    let stdout = "";
    const finish = (paths) => {
      if (completed) return;
      completed = true;
      if (timer) clearTimeout(timer);
      resolve(paths);
    };

    let child;
    try {
      child = spawn("powershell.exe", [
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        script,
      ], {
        windowsHide: true,
        stdio: ["ignore", "pipe", "ignore"],
      });
    } catch {
      finish([]);
      return;
    }

    child.stdout.on("data", (chunk) => { stdout += chunk.toString("utf8"); });
    child.once("error", () => finish([]));
    child.once("close", (code) => finish(code === 0 ? parseExplorerPaths(stdout) : []));

    const safeTimeout = Math.max(500, Math.min(1500, Number(timeoutMs) || 900));
    timer = setTimeout(() => {
      try { child.kill(); } catch {}
      finish([]);
    }, safeTimeout);
  });
}

module.exports = {
  getFocusedExplorerSelection,
  parseExplorerPaths,
  startExplorerSelectionService,
  stopExplorerSelectionService,
};
