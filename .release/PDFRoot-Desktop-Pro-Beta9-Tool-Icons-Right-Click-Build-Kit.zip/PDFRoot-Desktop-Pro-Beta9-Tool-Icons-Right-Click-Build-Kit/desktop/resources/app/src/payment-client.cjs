"use strict";
const fs = require("node:fs");
const path = require("node:path");

function paymentApiUrl(configPath, override = process.env.PDFROOT_PAYMENT_API_URL) {
  let value = override;
  if (!value) {
    try { value = JSON.parse(fs.readFileSync(configPath, "utf8")).baseUrl; } catch { return ""; }
  }
  if (!value) return "";
  const url = new URL(value);
  if (url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) {
    throw new Error("Payment service must use HTTPS.");
  }
  if (url.username || url.password || url.search || url.hash) throw new Error("Invalid payment service URL.");
  return url.origin + url.pathname.replace(/\/$/, "");
}

class PaymentClient {
  constructor({ baseUrl, userDataPath, deviceId, licenseStore, accountClient = null, fetchImpl = fetch }) {
    this.baseUrl = baseUrl;
    this.sessionPath = path.join(userDataPath, "pending-payment.json");
    this.deviceId = deviceId;
    this.licenseStore = licenseStore;
    this.accountClient = accountClient;
    this.fetchImpl = fetchImpl;
  }

  readSession() {
    try {
      const session = JSON.parse(fs.readFileSync(this.sessionPath, "utf8"));
      return session.checkoutId && session.token ? session : null;
    } catch { return null; }
  }

  async request(route, options = {}) {
    if (!this.baseUrl) throw new Error("Online payment is not set up yet. Contact PDFRoot for an activation code.");
    const response = await this.fetchImpl(this.baseUrl + route, { ...options, signal: AbortSignal.timeout(12000) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "The payment service could not respond.");
    return data;
  }

  async checkout(customerName) {
    const name = String(customerName || "").trim();
    if (name.length < 2 || name.length > 100) throw new Error("Enter your name first.");
    const pending = this.readSession();
    if (pending?.paymentUrl) {
      const result = await this.check();
      if (result.state === "pending") return { paymentUrl: pending.paymentUrl, amountPaise: pending.amountPaise, currency: pending.currency, expiresAt: pending.expiresAt };
      if (result.state === "active") throw new Error("Your payment is already confirmed. PDFRoot is active.");
    }
    const account = this.accountClient?.session();
    if (this.accountClient && !account) throw new Error("Sign in with your email before paying.");
    const data = await this.request("/v1/checkout", {
      method: "POST", headers: { "Content-Type": "application/json", ...(account ? { Authorization: `Bearer ${account.token}` } : {}) },
      body: JSON.stringify({ deviceId: this.deviceId, customerName: name, ...(account ? { clientVersion: 7 } : {}) }),
    });
    if (!/^[A-Za-z0-9_-]{1,40}$/.test(data.checkoutId || "") ||
        !/^[A-Za-z0-9_-]{40,60}$/.test(data.token || "") ||
        !/^https:\/\//.test(data.paymentUrl || "")) throw new Error("The payment service returned an invalid link.");
    fs.writeFileSync(this.sessionPath, JSON.stringify({ checkoutId: data.checkoutId, token: data.token,
      paymentUrl: data.paymentUrl, amountPaise: data.amountPaise, currency: data.currency, expiresAt: data.expiresAt }), { mode: 0o600 });
    return { paymentUrl: data.paymentUrl, amountPaise: data.amountPaise, currency: data.currency, expiresAt: data.expiresAt };
  }

  async check() {
    const session = this.readSession();
    if (!session) return this.accountClient ? this.accountClient.syncLicense() : { state: "none" };
    const data = await this.request(`/v1/status?checkoutId=${encodeURIComponent(session.checkoutId)}`, {
      headers: { "Authorization": `Bearer ${session.token}` },
    });
    if (data.state === "expired") {
      const synced = await this.accountClient?.syncLicense();
      return synced?.state === "active" ? synced : { state: "expired", expiresAt: data.expiresAt };
    }
    if (data.state !== "paid") return { state: "pending", expiresAt: data.expiresAt };
    const status = this.licenseStore.activate(data.code);
    if (!status.ok) throw new Error(`Paid license could not be activated: ${status.message}`);
    fs.rmSync(this.sessionPath, { force: true });
    return { state: "active", status };
  }
}

module.exports = { PaymentClient, paymentApiUrl };
