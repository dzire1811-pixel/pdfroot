const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { Jimp, JimpMime } = require("jimp");
const { cropSource, replaceCroppedImage, saveCroppedCopy } = require("./crop-replace.cjs");

test("Crop Save replaces the selected original with a valid image in its format", async () => {
  const directory = await fs.promises.mkdtemp(path.join(os.tmpdir(), "pdfroot-crop-"));
  const original = path.join(directory, "card.jpg");
  try {
    const before = await new Jimp({ width: 400, height: 300, color: 0x1c63d4ff })
      .getBuffer(JimpMime.jpeg, { quality: 88 });
    await fs.promises.writeFile(original, before);
    const source = await cropSource(original);
    const cropped = await new Jimp({ width: 100, height: 80, color: 0xeb862bff })
      .getBuffer(JimpMime.jpeg, { quality: 88 });
    const result = await replaceCroppedImage(original, {
      dataUrl: `data:image/jpeg;base64,${cropped.toString("base64")}`,
    }, source);
    assert.deepEqual({ width: result.width, height: result.height }, { width: 100, height: 80 });
    assert.deepEqual(await fs.promises.readFile(original), cropped);
    assert.deepEqual((await fs.promises.readdir(directory)).sort(), ["card.jpg"]);
  } finally {
    await fs.promises.rm(directory, { recursive: true, force: true });
  }
});

test("Invalid or stale crop result leaves the original image untouched", async () => {
  const directory = await fs.promises.mkdtemp(path.join(os.tmpdir(), "pdfroot-crop-"));
  const original = path.join(directory, "card.png");
  try {
    const bytes = await new Jimp({ width: 48, height: 40, color: 0xe93a34ff }).getBuffer(JimpMime.png);
    await fs.promises.writeFile(original, bytes);
    const source = await cropSource(original);
    await assert.rejects(replaceCroppedImage(original, { dataUrl: "data:image/png;base64,aW52YWxpZA==" }, source));
    await assert.rejects(replaceCroppedImage(original, { dataUrl: source.dataUrl }, { ...source, originalSize: source.originalSize + 1 }), /changed while the editor was open/);
    assert.deepEqual(await fs.promises.readFile(original), bytes);
  } finally {
    await fs.promises.rm(directory, { recursive: true, force: true });
  }
});

test("Copy creates separate cropped files and preserves the replaced original", async () => {
  const directory = await fs.promises.mkdtemp(path.join(os.tmpdir(), "pdfroot-crop-copy-"));
  const original = path.join(directory, "scan.jpg");
  try {
    const scan = await new Jimp({ width: 120, height: 90, color: 0xffffffff }).getBuffer(JimpMime.jpeg);
    const photo = await new Jimp({ width: 50, height: 60, color: 0xeb4d39ff }).getBuffer(JimpMime.jpeg);
    const signature = await new Jimp({ width: 100, height: 20, color: 0x133dcfff }).getBuffer(JimpMime.jpeg);
    await fs.promises.writeFile(original, scan);
    const source = await cropSource(original);
    await replaceCroppedImage(original, { dataUrl: `data:image/jpeg;base64,${photo.toString("base64")}` }, source);
    const first = await saveCroppedCopy(original, { dataUrl: `data:image/jpeg;base64,${signature.toString("base64")}` });
    const second = await saveCroppedCopy(original, { dataUrl: `data:image/jpeg;base64,${scan.toString("base64")}` });
    assert.equal(path.basename(first.outputPath), "scan-copy-2.jpg");
    assert.equal(path.basename(second.outputPath), "scan-copy-3.jpg");
    assert.deepEqual(await fs.promises.readFile(original), photo);
    assert.deepEqual(await fs.promises.readFile(first.outputPath), signature);
  } finally {
    await fs.promises.rm(directory, { recursive: true, force: true });
  }
});
