const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { automaticTools, nextAvailableOutputPath, validateAutomaticSelection } = require("./automatic-mode.cjs");

function makeFiles(names) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "pdfroot-auto-"));
  const files = names.map((name) => {
    const filePath = path.join(directory, name);
    fs.writeFileSync(filePath, "test");
    return filePath;
  });
  return { directory, files };
}

test("Auto Mode covers every safe default shortcut workflow", () => {
  assert.deepEqual(Object.keys(automaticTools).sort(), [
    "compress-image",
    "compress-pdf",
    "crop-image",
    "excel-to-pdf",
    "front-back-card-merge",
    "gpsc-photo-resize",
    "ibps-photo-resize",
    "image-compressor-for-government-forms",
    "jpg-to-pdf",
    "jpg-to-png",
    "merge-pdf",
    "ojas-photo-resize",
    "pdf-to-excel",
    "pdf-to-jpg",
    "pdf-to-word",
    "png-to-jpg",
    "png-to-pdf",
    "powerpoint-to-pdf",
    "resize-image-to-exact-kb",
    "rrb-signature-resize",
    "signature-resize-tool",
    "ssc-photo-resize",
    "upsc-photo-resize",
    "word-to-pdf",
  ]);
});

test("Merge PDF requires two selected PDF files", () => {
  const setup = makeFiles(["one.pdf", "two.pdf"]);
  try {
    assert.equal(validateAutomaticSelection("merge-pdf", [setup.files[0]]).ok, false);
    const valid = validateAutomaticSelection("merge-pdf", setup.files);
    assert.equal(valid.ok, true);
    assert.equal(valid.files.length, 2);
  } finally {
    fs.rmSync(setup.directory, { recursive: true, force: true });
  }
});

test("Crop Image accepts multiple selected images for one editor session", () => {
  const setup = makeFiles(["photo.jpg", "signature.png", "scan.webp"]);
  try {
    const result = validateAutomaticSelection("crop-image", setup.files);
    assert.equal(result.ok, true);
    assert.deepEqual(result.files, setup.files);
  } finally {
    fs.rmSync(setup.directory, { recursive: true, force: true });
  }
});

test("Auto Mode rejects a mixed selection instead of silently processing the wrong file", () => {
  const setup = makeFiles(["photo.jpg", "notes.pdf"]);
  try {
    const result = validateAutomaticSelection("jpg-to-pdf", setup.files);
    assert.equal(result.ok, false);
    assert.match(result.message, /accepts only/i);
  } finally {
    fs.rmSync(setup.directory, { recursive: true, force: true });
  }
});

test("Front and back merge requires exactly two supported images", () => {
  const setup = makeFiles(["front.jpg", "back.jpg", "extra.jpg"]);
  try {
    assert.equal(validateAutomaticSelection("front-back-card-merge", setup.files.slice(0, 2)).ok, true);
    const tooMany = validateAutomaticSelection("front-back-card-merge", setup.files);
    assert.equal(tooMany.ok, false);
    assert.match(tooMany.message, /exactly 2/i);
  } finally {
    fs.rmSync(setup.directory, { recursive: true, force: true });
  }
});

test("Word to PDF accepts one Word file only", () => {
  const setup = makeFiles(["one.docx", "two.docx"]);
  try {
    assert.equal(validateAutomaticSelection("word-to-pdf", [setup.files[0]]).ok, true);
    assert.equal(validateAutomaticSelection("word-to-pdf", setup.files).ok, false);
  } finally {
    fs.rmSync(setup.directory, { recursive: true, force: true });
  }
});

test("automatic download names do not overwrite an existing result", () => {
  const setup = makeFiles(["PDFRoot-merged.pdf"]);
  try {
    const outputPath = nextAvailableOutputPath(setup.directory, "PDFRoot-merged.pdf");
    assert.equal(path.basename(outputPath), "PDFRoot-merged (1).pdf");
  } finally {
    fs.rmSync(setup.directory, { recursive: true, force: true });
  }
});

test("Auto Mode never opens a visible tool-window fallback", () => {
  const mainSource = fs.readFileSync(path.join(__dirname, "main.cjs"), "utf8");
  const failFunction = mainSource.match(/function failAutoJob\(job, message\) \{([\s\S]*?)\n\}/);
  const automaticStart = mainSource.match(/async function startAutomaticTool\([\s\S]*?\n\}/);
  assert.ok(failFunction, "Auto Mode failure handler should exist");
  assert.doesNotMatch(failFunction[1], /openTool\(/);
  assert.ok(automaticStart, "Auto Mode start function should exist");
  assert.doesNotMatch(automaticStart[0], /openTool\(/);
  assert.match(mainSource, /show: false,[\s\S]*?skipTaskbar: true/);
});

test("Compress PDF uses only the compact Normal, Low, Heavy chooser in Auto Mode", () => {
  const mainSource = fs.readFileSync(path.join(__dirname, "main.cjs"), "utf8");
  const choiceSource = fs.readFileSync(path.join(__dirname, "ui", "compression-choice.html"), "utf8");
  assert.match(mainSource, /startCompressionShortcut\(selectedFiles, shortcut, accelerator\)/);
  assert.match(mainSource, /choosePdfCompressionLevel\(selection\.files\.length\)/);
  assert.deepEqual([...choiceSource.matchAll(/data-level="([^"]+)"/g)].map((match) => match[1]), ["normal", "low", "heavy"]);
  assert.doesNotMatch(choiceSource, /https?:\/\//i);
});
