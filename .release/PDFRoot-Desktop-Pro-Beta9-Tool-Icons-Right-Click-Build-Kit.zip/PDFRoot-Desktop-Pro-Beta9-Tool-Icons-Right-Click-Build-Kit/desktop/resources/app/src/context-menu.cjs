const path = require("node:path");
const { getTool } = require("./catalog.cjs");

const pdfInputSlugs = Object.freeze([
  "merge-pdf",
  "split-pdf",
  "compress-pdf",
  "pdf-to-word",
  "pdf-to-excel",
  "pdf-to-powerpoint",
  "pdf-to-jpg",
  "rotate-pdf",
  "organize-pdf-pages",
  "delete-pdf-pages",
  "watermark-pdf",
  "crop-pdf",
  "protect-pdf",
  "unlock-pdf",
  "edit-pdf",
]);

const imageInputSlugs = Object.freeze([
  "jpg-to-pdf",
  "png-to-pdf",
  "resize-image-to-exact-kb",
  "compress-image",
  "crop-image",
  "resize-image",
  "jpg-to-png",
  "png-to-jpg",
  "signature-resize-tool",
  "image-compressor-for-government-forms",
  "ssc-photo-resize",
  "rrb-signature-resize",
  "ibps-photo-resize",
  "ojas-photo-resize",
  "gpsc-photo-resize",
  "upsc-photo-resize",
  "front-back-card-merge",
]);

function menuTool(slug, group) {
  const tool = getTool(slug);
  if (!tool) throw new Error(`Context-menu tool is missing from the catalog: ${slug}`);
  return Object.freeze({ slug, label: tool.name, group });
}

const contextMenuTools = Object.freeze([
  Object.freeze({ slug: "catalog", label: "Open All PDFRoot Tools", group: "catalog" }),
  ...pdfInputSlugs.map((slug) => menuTool(slug, "pdf")),
  ...imageInputSlugs.map((slug) => menuTool(slug, "image")),
]);

const contextMenuSlugs = new Set(contextMenuTools.map((tool) => tool.slug));
const contextToolGroups = new Map(contextMenuTools.map((tool) => [tool.slug, tool.group]));
const imageExtensions = new Set([".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"]);

function readContextTool(commandLine) {
  if (!Array.isArray(commandLine)) return null;
  const argument = commandLine.find((item) => typeof item === "string" && item.startsWith("--context-tool="));
  if (!argument) return null;
  const slug = argument.slice("--context-tool=".length).trim().toLowerCase();
  return contextMenuSlugs.has(slug) ? slug : null;
}

function contextToolGroup(slug) {
  return contextToolGroups.get(slug) || null;
}

function contextToolAcceptsFiles(slug, files) {
  const group = contextToolGroup(slug);
  if (!group) return false;
  if (group === "catalog") return true;
  if (!Array.isArray(files) || !files.length) return false;
  const extensions = files.map((filePath) => typeof filePath === "string" ? path.extname(filePath).toLowerCase() : "");
  if (group === "pdf") return extensions.every((extension) => extension === ".pdf");
  if (group === "image") return extensions.every((extension) => imageExtensions.has(extension));
  return false;
}

module.exports = {
  contextMenuTools,
  contextToolAcceptsFiles,
  contextToolGroup,
  imageInputSlugs,
  pdfInputSlugs,
  readContextTool,
};
