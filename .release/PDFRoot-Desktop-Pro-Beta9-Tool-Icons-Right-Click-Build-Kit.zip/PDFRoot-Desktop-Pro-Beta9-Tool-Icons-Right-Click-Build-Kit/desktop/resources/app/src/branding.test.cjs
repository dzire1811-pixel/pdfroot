const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { desktopBrandInjectionScript, officialPdfRootLogoSvg } = require("./branding.cjs");

test("desktop branding uses the interlocking PDFRoot dark red and black mark", () => {
  assert.match(officialPdfRootLogoSvg, /#B91C1C/);
  assert.match(officialPdfRootLogoSvg, /#111111/);
  assert.match(officialPdfRootLogoSvg, /PDFRoot/);
});

test("every hosted tool can receive a non-interactive branded Desktop Pro badge", () => {
  const script = desktopBrandInjectionScript({ mode: "auto" });
  assert.match(script, /pdfroot-desktop-brand-badge/);
  assert.match(script, /pointer-events:none/);
  assert.match(script, /PDFRoot Desktop Pro/);
  assert.match(script, /AUTO MODE/);
});

test("catalog uses the scoped dark workspace while preserving the original logo", () => {
  const uiDirectory = path.join(__dirname, "ui");
  const catalog = fs.readFileSync(path.join(uiDirectory, "catalog.html"), "utf8");
  const styles = fs.readFileSync(path.join(uiDirectory, "app.css"), "utf8");
  const logo = fs.readFileSync(path.join(uiDirectory, "pdfroot-logo.svg"), "utf8");

  assert.match(catalog, /<body class="catalog-page intro-active">/);
  assert.match(catalog, /class="workspace-preferences"/);
  assert.match(styles, /body\.catalog-page\s*\{[^}]*color-scheme:\s*dark;/s);
  assert.match(styles, /\.catalog-page \.tool-card\s*\{[^}]*background:\s*#171a20;/s);
  assert.match(styles, /\.catalog-page \.tool-card h3\s*\{[^}]*color:\s*#f4f4f5;/s);
  assert.match(styles, /\.catalog-page \.topbar-status \.windows-pill\s*\{[^}]*display:\s*flex !important;/s);
  assert.match(styles, /\.catalog-page \.workspace-preferences\s*\{[^}]*grid-template-columns:\s*minmax\(0, 1\.35fr\)/s);
  assert.match(logo, /#B91C1C/);
  assert.match(logo, /#111111/);
});
