const tools = [
  { name: "Merge PDF", slug: "merge-pdf", category: "PDF", description: "Combine multiple PDF files into one organized document." },
  { name: "Split PDF", slug: "split-pdf", category: "PDF", description: "Split a PDF or extract selected page ranges." },
  { name: "Compress PDF", slug: "compress-pdf", category: "PDF", description: "Reduce PDF file size for portals and email." },
  { name: "PDF to Word", slug: "pdf-to-word", category: "PDF", description: "Convert a PDF into an editable Word document." },
  { name: "PDF to Excel", slug: "pdf-to-excel", category: "PDF", description: "Extract PDF tables into an Excel-ready file." },
  { name: "PDF to PowerPoint", slug: "pdf-to-powerpoint", category: "PDF", description: "Turn PDF pages into presentation slides." },
  { name: "PDF to JPG", slug: "pdf-to-jpg", category: "PDF", description: "Convert PDF pages into clear JPG images." },
  { name: "JPG to PDF", slug: "jpg-to-pdf", category: "PDF", description: "Create a clean PDF from JPG images." },
  { name: "PNG to PDF", slug: "png-to-pdf", category: "PDF", description: "Convert PNG images into one PDF." },
  { name: "Word to PDF", slug: "word-to-pdf", category: "PDF", description: "Turn a Word document into a PDF." },
  { name: "Excel to PDF", slug: "excel-to-pdf", category: "PDF", description: "Export spreadsheet data as PDF." },
  { name: "PowerPoint to PDF", slug: "powerpoint-to-pdf", category: "PDF", description: "Export a presentation as a PDF." },
  { name: "Rotate PDF", slug: "rotate-pdf", category: "PDF", description: "Fix the orientation of PDF pages." },
  { name: "Organize PDF Pages", slug: "organize-pdf-pages", category: "PDF", description: "Reorder and manage pages in a PDF." },
  { name: "Delete PDF Pages", slug: "delete-pdf-pages", category: "PDF", description: "Remove unwanted PDF pages." },
  { name: "Watermark PDF", slug: "watermark-pdf", category: "PDF", description: "Add a text or image watermark." },
  { name: "Crop PDF", slug: "crop-pdf", category: "PDF", description: "Remove extra margins from PDF pages." },
  { name: "Protect PDF", slug: "protect-pdf", category: "PDF", description: "Add a password to a PDF." },
  { name: "Unlock PDF", slug: "unlock-pdf", category: "PDF", description: "Remove a supported password when you have permission." },
  { name: "Edit PDF", slug: "edit-pdf", category: "PDF", description: "Edit text, add images, signatures and highlights." },
  { name: "Resize Image to Exact KB", slug: "resize-image-to-exact-kb", category: "Image", description: "Make a photo 20KB, 50KB, 100KB or any target KB." },
  { name: "Compress Image", slug: "compress-image", category: "Image", description: "Reduce JPG, PNG and WebP image size." },
  { name: "Crop Image", slug: "crop-image", category: "Image", description: "Crop, rotate, flip and adjust an image." },
  { name: "Resize Image", slug: "resize-image", category: "Image", description: "Set exact image width and height." },
  { name: "JPG to PNG", slug: "jpg-to-png", category: "Image", description: "Convert JPG images to PNG." },
  { name: "PNG to JPG", slug: "png-to-jpg", category: "Image", description: "Convert PNG images to JPG." },
  { name: "Signature Resize Tool", slug: "signature-resize-tool", category: "Image", description: "Resize signatures to exact file-size limits." },
  { name: "Govt. Form Image Compressor", slug: "image-compressor-for-government-forms", category: "Image", description: "Compress photos and signatures for government forms." },
  { name: "SSC Photo & Signature Resize", slug: "ssc-photo-resize", category: "Government", description: "Prepare SSC photo and signature files." },
  { name: "RRB Signature Resize", slug: "rrb-signature-resize", category: "Government", description: "Prepare Railway/RRB signature files." },
  { name: "IBPS Photo, Signature, Thumb & Declaration", slug: "ibps-photo-resize", category: "Government", description: "Prepare all IBPS recruitment uploads." },
  { name: "OJAS Photo Resize", slug: "ojas-photo-resize", category: "Government", description: "Prepare OJAS Gujarat photos and signatures." },
  { name: "GPSC Photo Resize", slug: "gpsc-photo-resize", category: "Government", description: "Prepare GPSC form photos and signatures." },
  { name: "UPSC Photo Resize", slug: "upsc-photo-resize", category: "Government", description: "Prepare UPSC application photo and signature." },
  { name: "Front & Back Card Merge", slug: "front-back-card-merge", category: "Government", description: "Merge Aadhaar, PAN or ID-card front and back." },
];

function getTool(slug) {
  return tools.find((tool) => tool.slug === slug);
}

module.exports = { tools, getTool };
