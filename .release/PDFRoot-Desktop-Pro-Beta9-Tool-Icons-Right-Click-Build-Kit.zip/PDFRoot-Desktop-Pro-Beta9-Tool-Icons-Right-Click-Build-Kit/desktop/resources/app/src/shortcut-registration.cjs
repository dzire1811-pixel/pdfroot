function displayAccelerator(accelerator) {
  return String(accelerator || "")
    .replace(/Control/g, "Ctrl")
    .replace(/CommandOrControl/g, "Ctrl")
    .split("+")
    .join(" + ");
}

function registrationCandidates(shortcut) {
  return [shortcut.accelerator, shortcut.fallbackAccelerator, shortcut.backupAccelerator]
    .filter((accelerator) => typeof accelerator === "string" && accelerator.trim())
    .filter((accelerator, index, values) => values.indexOf(accelerator) === index);
}

function registerShortcutSet({ shortcuts, register, unregisterAll, handler }) {
  if (typeof unregisterAll === "function") unregisterAll();

  const results = new Map();
  for (const shortcut of shortcuts) {
    const candidates = registrationCandidates(shortcut);
    const registeredAccelerators = [];

    for (const accelerator of candidates) {
      try {
        if (register(accelerator, () => handler(shortcut, accelerator))) registeredAccelerators.push(accelerator);
      } catch {
        // A malformed or externally reserved accelerator must not stop the rest.
      }
    }

    const effectiveAccelerator = registeredAccelerators.includes(shortcut.accelerator)
      ? shortcut.accelerator
      : registeredAccelerators[0] || null;
    const alternateAccelerators = registeredAccelerators.filter((accelerator) => accelerator !== effectiveAccelerator);

    results.set(shortcut.accelerator, {
      registered: Boolean(effectiveAccelerator),
      effectiveAccelerator,
      effectiveDisplay: effectiveAccelerator ? displayAccelerator(effectiveAccelerator) : shortcut.display,
      usedFallback: Boolean(effectiveAccelerator && effectiveAccelerator !== shortcut.accelerator),
      candidates,
      registeredAccelerators,
      alternateAccelerators,
      alternateDisplays: alternateAccelerators.map(displayAccelerator),
    });
  }
  return results;
}

module.exports = { displayAccelerator, registrationCandidates, registerShortcutSet };
