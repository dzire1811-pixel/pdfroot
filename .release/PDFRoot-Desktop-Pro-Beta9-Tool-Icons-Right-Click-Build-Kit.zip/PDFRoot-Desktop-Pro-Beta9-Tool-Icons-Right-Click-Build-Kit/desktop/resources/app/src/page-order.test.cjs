const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { PDFDocument } = require("pdf-lib");
const { Jimp, JimpMime } = require("jimp");
const { createPagePreviews, validatePageOrder } = require("./page-order.cjs");

test("page order validation rejects missing, duplicated and invented pages", () => {
  assert.equal(validatePageOrder(["0:0", "1:1", "1:0"], [1, 2]), true);
  assert.equal(validatePageOrder(["0:0", "1:0"], [1, 2]), false);
  assert.equal(validatePageOrder(["0:0", "1:1", "1:1"], [1, 2]), false);
  assert.equal(validatePageOrder(["0:0", "1:0", "2:0"], [1, 2]), false);
});

test("wide preview represents every selected image and every PDF page", async () => {
  const directory = await fs.promises.mkdtemp(path.join(os.tmpdir(), "pdfroot-order-"));
  try {
    const image = new Jimp({ width: 80, height: 120, color: 0x22bbeeFF });
    const firstImage = path.join(directory, "image-one.jpg");
    const secondImage = path.join(directory, "image-two.jpg");
    await fs.promises.writeFile(firstImage, await image.getBuffer(JimpMime.jpeg, { quality: 80 }));
    await fs.promises.writeFile(secondImage, await image.getBuffer(JimpMime.jpeg, { quality: 80 }));
    const imagePreview = await createPagePreviews("jpg-to-pdf", [firstImage, secondImage]);
    assert.deepEqual(imagePreview.pages.map((page) => page.id), ["0:0", "1:0"]);
    assert.ok(imagePreview.pages.every((page) => page.preview.startsWith("data:image/jpeg;base64,")));

    const pdf = await PDFDocument.create();
    pdf.addPage([100, 200]);
    pdf.addPage([200, 100]);
    const pdfPath = path.join(directory, "two-pages.pdf");
    await fs.promises.writeFile(pdfPath, await pdf.save());
    const pdfPreview = await createPagePreviews("merge-pdf", [pdfPath], async () => ["aGVsbG8=", "aGVsbG8="]);
    assert.deepEqual(pdfPreview.pages.map((page) => page.id), ["0:0", "0:1"]);
    assert.equal(pdfPreview.pages[1].pageNumber, 2);
  } finally {
    await fs.promises.rm(directory, { recursive: true, force: true });
  }
});
