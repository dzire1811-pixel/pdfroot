const IMAGE_PRESETS = Object.freeze({
  "ssc-photo-resize": Object.freeze({
    photo: Object.freeze({ width: 200, height: 230, maxKb: 50, cover: true }),
    signature: Object.freeze({ width: 600, height: 200, maxKb: 20 }),
  }),
  "rrb-signature-resize": Object.freeze({
    signature: Object.freeze({ width: 140, height: 60, minKb: 30, maxKb: 49 }),
  }),
  "ibps-photo-resize": Object.freeze({
    photo: Object.freeze({ width: 200, height: 230, maxKb: 50, cover: true }),
    signature: Object.freeze({ width: 140, height: 60, maxKb: 20 }),
    thumb: Object.freeze({ width: 240, height: 240, maxKb: 50 }),
    declaration: Object.freeze({ width: 800, height: 400, maxKb: 100 }),
  }),
  "ojas-photo-resize": Object.freeze({
    photo: Object.freeze({ width: 425, height: 591, maxKb: 14, cover: true, date: true }),
  }),
  "gpsc-photo-resize": Object.freeze({
    photo: Object.freeze({ width: 300, height: 400, maxKb: 15, strictlyUnder: true, cover: true, date: true }),
  }),
  "upsc-photo-resize": Object.freeze({
    photo: Object.freeze({ width: 350, height: 450, maxKb: 100, cover: true }),
    signature: Object.freeze({ width: 350, height: 120, maxKb: 40 }),
  }),
});

function parseTargetKb(value) {
  const number = Number(value);
  return Number.isInteger(number) && number >= 5 && number <= 2048 ? number : undefined;
}

function localDate(today = new Date()) {
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parsePhotoDate(value, today = new Date()) {
  const date = value || localDate(today);
  if (typeof date !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return undefined;
  const [year, month, day] = date.split("-").map(Number);
  const parsed = new Date(year, month - 1, day);
  if (parsed.getFullYear() !== year || parsed.getMonth() !== month - 1 || parsed.getDate() !== day) return undefined;
  return { iso: date, display: `${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}/${year}` };
}

function presetFor(slug, kind) {
  return IMAGE_PRESETS[slug]?.[kind];
}

module.exports = { IMAGE_PRESETS, parseTargetKb, localDate, parsePhotoDate, presetFor };
