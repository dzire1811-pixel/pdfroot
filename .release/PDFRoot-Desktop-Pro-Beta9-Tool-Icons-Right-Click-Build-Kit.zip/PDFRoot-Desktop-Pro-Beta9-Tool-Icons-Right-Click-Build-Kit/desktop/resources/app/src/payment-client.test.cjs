const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { PaymentClient, paymentApiUrl } = require("./payment-client.cjs");
const { LicenseStore, createLicenseCode } = require("./license.cjs");

test("resumes a paid checkout and activates without pasting a code", async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "pdfroot-client-test-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const keys = crypto.generateKeyPairSync("ed25519", { privateKeyEncoding: { type: "pkcs8", format: "pem" }, publicKeyEncoding: { type: "spki", format: "pem" } });
  const keyPath = path.join(dir, "public.pem");
  fs.writeFileSync(keyPath, keys.publicKey);
  const deviceId = "B".repeat(32);
  const store = new LicenseStore({ userDataPath: dir, publicKeyPath: keyPath, deviceHash: deviceId });
  let state = "pending";
  let created = 0;
  const code = createLicenseCode({ version: 1, issuer: "PDFRoot", licenseId: "PDR-TEST", plan: "monthly", source: "razorpay-payment",
    deviceHash: deviceId, issuedAt: new Date(Date.now() - 1000).toISOString(), expiresAt: new Date(Date.now() + 30 * 86400000).toISOString() }, keys.privateKey);
  const mockFetch = async (url) => {
    if (url.includes("/v1/checkout")) {
      created++;
      return { ok: true, json: async () => ({ checkoutId: "PDRTEST", token: "X".repeat(43), paymentUrl: "https://rzp.io/i/mock", amountPaise: 9900, currency: "INR" }) };
    }
    return { ok: true, json: async () => ({ state, ...(state === "paid" ? { code } : {}) }) };
  };
  const client = new PaymentClient({ baseUrl: "https://payment.example", userDataPath: dir, deviceId, licenseStore: store, fetchImpl: mockFetch });
  assert.equal((await client.checkout("Buyer Name")).currency, "INR");
  assert.equal((await client.checkout("Buyer Name")).paymentUrl, "https://rzp.io/i/mock");
  assert.equal(created, 1);
  assert.equal((await client.check()).state, "pending");
  state = "paid";
  assert.equal((await client.check()).state, "active");
  assert.equal(store.getStatus().ok, true);
  assert.equal(client.readSession(), null);
});

test("requires HTTPS for a remote payment server", () => {
  assert.throws(() => paymentApiUrl("irrelevant", "http://example.com"), /HTTPS/);
  assert.equal(paymentApiUrl("irrelevant", "https://pay.pdfroot.com/"), "https://pay.pdfroot.com");
});
