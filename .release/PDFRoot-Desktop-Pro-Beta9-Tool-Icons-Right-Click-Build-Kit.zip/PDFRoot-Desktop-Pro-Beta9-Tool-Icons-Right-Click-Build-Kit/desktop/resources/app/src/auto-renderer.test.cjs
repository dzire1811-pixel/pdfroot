const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

test("PDF-to-JPG returns pages and destroys the PDF.js loading task", async () => {
  let destroyed = 0;
  let cleaned = 0;
  const page = {
    getViewport: ({ scale }) => ({ width: 100 * scale, height: 150 * scale }),
    render: () => ({ promise: Promise.resolve() }),
    cleanup: () => { cleaned += 1; },
  };
  const loadingTask = {
    promise: Promise.resolve({ numPages: 1, getPage: async () => page }),
    destroy: async () => { destroyed += 1; },
  };
  const context = vm.createContext({
    pdfjsLib: { getDocument: () => loadingTask },
    atob: () => "%PDF",
    window: {},
    document: { createElement: () => ({
      getContext: () => ({ fillRect: () => {} }),
      toDataURL: () => "data:image/jpeg;base64,/9j/",
    }) },
  });
  const source = fs.readFileSync(path.join(__dirname, "ui", "auto-renderer.js"), "utf8")
    .replace(/^import .*;\n/m, "")
    .replace(/^pdfjsLib\.GlobalWorkerOptions\.workerSrc.*;\n/m, "");
  vm.runInContext(source, context);
  const images = await context.window.pdfrootLocalRenderer.renderPdfToJpg({ base64: "JVBERg==" });
  assert.deepEqual(Array.from(images), ["/9j/"]);
  assert.equal(cleaned, 1);
  assert.equal(destroyed, 1);
});
