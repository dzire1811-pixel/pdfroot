const fs = require("node:fs");
const path = require("node:path");
const { execFile } = require("node:child_process");
const { promisify } = require("node:util");

const execFileAsync = promisify(execFile);
let discoveredPython;

// The older PDFRoot Desktop Tools installation has PyMuPDF and Pillow in its
// own virtual environment. Resolve its desktop shortcut once per app launch.
async function findDesktopToolsPython() {
  if (discoveredPython) return discoveredPython;
  discoveredPython = (async () => {
    const override = process.env.PDFROOT_DESKTOP_TOOLS_PYTHON;
    if (override && fs.existsSync(override)) return override;
    if (process.platform !== "win32") return null;
    const script = `
$ErrorActionPreference = 'Stop'
$ws = New-Object -ComObject WScript.Shell
$folders = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Startup'))
if ($env:USERPROFILE) { $folders += (Join-Path $env:USERPROFILE 'Desktop') }
foreach ($drive in @($env:OneDrive, $env:OneDriveConsumer, $env:OneDriveCommercial)) {
  if ($drive) { $folders += (Join-Path $drive 'Desktop') }
}
foreach ($folder in ($folders | Where-Object { $_ } | Select-Object -Unique)) {
  $shortcut = Join-Path $folder 'PDFRoot Desktop Tools.lnk'
  if (-not (Test-Path -LiteralPath $shortcut -PathType Leaf)) { continue }
  $target = $ws.CreateShortcut($shortcut).TargetPath
  if (-not $target -or [IO.Path]::GetFileName($target) -ine 'pythonw.exe') { continue }
  $scripts = [IO.Path]::GetDirectoryName($target)
  if ([IO.Path]::GetFileName($scripts) -ine 'Scripts') { continue }
  $venv = [IO.Path]::GetDirectoryName($scripts)
  if ([IO.Path]::GetFileName($venv) -ine '.venv') { continue }
  $python = Join-Path $scripts 'python.exe'
  $source = Join-Path ([IO.Path]::GetDirectoryName($venv)) 'pdfroot_desktop.pyw'
  if ((Test-Path -LiteralPath $python -PathType Leaf) -and (Test-Path -LiteralPath $source -PathType Leaf)) {
    [Console]::Out.Write($python)
    break
  }
}`;
    try {
      const { stdout } = await execFileAsync("powershell.exe", [
        "-NoProfile", "-NonInteractive", "-EncodedCommand", Buffer.from(script, "utf16le").toString("base64"),
      ], { windowsHide: true, timeout: 7000, maxBuffer: 16384 });
      const candidate = stdout.trim();
      return candidate && fs.existsSync(candidate) ? candidate : null;
    } catch {
      return null;
    }
  })();
  return discoveredPython;
}

async function renderWithDesktopTools(python, filePath, options) {
  const helper = path.join(__dirname, "pdf-render-fallback.py");
  const { stdout } = await execFileAsync(python, [helper, filePath, JSON.stringify(options)], {
    windowsHide: true,
    timeout: 120000,
    maxBuffer: 128 * 1024 * 1024,
  });
  const pages = JSON.parse(stdout);
  if (!Array.isArray(pages) || !pages.length ||
      !pages.every((entry) => typeof entry === "string" && entry.length > 2)) {
    throw new Error("Desktop Tools did not produce JPG pages.");
  }
  return pages;
}

module.exports = { findDesktopToolsPython, renderWithDesktopTools };
