const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { getTool, tools } = require("./catalog.cjs");
const { quickShortcuts } = require("./shortcuts.cjs");

test("catalog contains the current 35-tool PDFRoot desktop inventory without duplicates", () => {
  assert.equal(tools.length, 35);
  assert.equal(new Set(tools.map((tool) => tool.slug)).size, tools.length);
  assert.ok(tools.some((tool) => tool.slug === "edit-pdf"));
  assert.ok(tools.some((tool) => tool.slug === "front-back-card-merge"));
  assert.equal(getTool("background-remover"), undefined);
  assert.equal(getTool("passport-photo-maker"), undefined);
});

test("every direct shortcut points to a catalog tool", () => {
  for (const shortcut of quickShortcuts.filter((shortcut) => shortcut.slug)) {
    assert.ok(getTool(shortcut.slug), `${shortcut.display} needs a valid catalog tool`);
  }
});

test("every catalog tool ships with its own website-style SVG icon", () => {
  for (const tool of tools) {
    const iconPath = path.join(__dirname, "ui", "tool-icons", `${tool.slug}.svg`);
    assert.ok(fs.existsSync(iconPath), `${tool.slug} needs a bundled tool icon`);
  }
});

test("each shortcut has a distinct Windows fallback binding", () => {
  const fallbacks = quickShortcuts.map((shortcut) => shortcut.fallbackAccelerator);
  assert.equal(fallbacks.filter(Boolean).length, quickShortcuts.length);
  assert.equal(new Set(fallbacks).size, quickShortcuts.length);
});

test("each shortcut has a distinct independent backup binding", () => {
  const backups = quickShortcuts.map((shortcut) => shortcut.backupAccelerator);
  const directAndFallbacks = new Set(quickShortcuts.flatMap((shortcut) => [
    shortcut.accelerator,
    shortcut.fallbackAccelerator,
  ]));

  assert.equal(backups.filter(Boolean).length, quickShortcuts.length);
  assert.equal(new Set(backups).size, quickShortcuts.length);
  assert.equal(backups.some((accelerator) => directAndFallbacks.has(accelerator)), false);
});
