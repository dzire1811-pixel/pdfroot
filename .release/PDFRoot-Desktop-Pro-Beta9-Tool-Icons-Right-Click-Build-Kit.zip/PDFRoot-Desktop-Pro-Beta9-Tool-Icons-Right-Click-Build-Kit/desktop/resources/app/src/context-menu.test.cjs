const test = require("node:test");
const assert = require("node:assert/strict");
const { tools } = require("./catalog.cjs");
const {
  contextMenuTools,
  contextToolAcceptsFiles,
  imageInputSlugs,
  pdfInputSlugs,
  readContextTool,
} = require("./context-menu.cjs");

test("right-click menu includes every PDF-input and image-input catalog tool", () => {
  assert.equal(pdfInputSlugs.length, 15);
  assert.equal(imageInputSlugs.length, 17);
  assert.equal(contextMenuTools.length, 33);
  const catalogSlugs = new Set(tools.map((tool) => tool.slug));
  for (const tool of contextMenuTools) {
    if (tool.slug !== "catalog") assert.equal(catalogSlugs.has(tool.slug), true, tool.slug);
  }
  assert.equal(contextMenuTools.some((tool) => tool.slug === "word-to-pdf"), false);
  assert.equal(contextMenuTools.some((tool) => tool.slug === "excel-to-pdf"), false);
  assert.equal(contextMenuTools.some((tool) => tool.slug === "powerpoint-to-pdf"), false);
});

test("right-click launcher accepts every installed context-menu tool", () => {
  for (const tool of contextMenuTools) {
    assert.equal(readContextTool(["PDFRoot Desktop Pro.exe", `--context-tool=${tool.slug}`]), tool.slug);
  }
});

test("right-click launcher rejects unknown or malformed tool arguments", () => {
  assert.equal(readContextTool(["PDFRoot Desktop Pro.exe", "--context-tool=unknown-tool"]), null);
  assert.equal(readContextTool(["PDFRoot Desktop Pro.exe", "--tool=merge-pdf"]), null);
  assert.equal(readContextTool(null), null);
});

test("right-click PDF tools accept only PDF selections", () => {
  assert.equal(contextToolAcceptsFiles("compress-pdf", ["a.pdf"]), true);
  assert.equal(contextToolAcceptsFiles("merge-pdf", ["a.PDF", "b.pdf"]), true);
  assert.equal(contextToolAcceptsFiles("pdf-to-jpg", ["photo.jpg"]), false);
  assert.equal(contextToolAcceptsFiles("merge-pdf", ["a.pdf", "photo.png"]), false);
  for (const slug of pdfInputSlugs) assert.equal(contextToolAcceptsFiles(slug, ["document.pdf"]), true, slug);
});

test("right-click image tools accept only supported image selections", () => {
  assert.equal(contextToolAcceptsFiles("crop-image", ["photo.jpg"]), true);
  assert.equal(contextToolAcceptsFiles("front-back-card-merge", ["front.png", "back.webp"]), true);
  assert.equal(contextToolAcceptsFiles("resize-image-to-exact-kb", ["document.pdf"]), false);
  assert.equal(contextToolAcceptsFiles("crop-image", ["photo.jpg", "document.pdf"]), false);
  for (const slug of imageInputSlugs) assert.equal(contextToolAcceptsFiles(slug, ["photo.jpg"]), true, slug);
});
