"""Render PDF pages locally with the existing Desktop Tools virtual environment."""
import base64
import io
import json
import math
import sys

import fitz
from PIL import Image


def bounded(value, default, minimum, maximum):
    try:
        number = float(value)
        return max(minimum, min(maximum, number)) if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def render(file_path, options):
    scale = bounded(options.get("scale"), 1.2, 0.6, 2.5)
    quality = round(bounded(options.get("quality"), 0.84, 0.4, 0.95) * 100)
    max_side = round(bounded(options.get("maximumSide"), 2200, 900, 3000))
    pages = []
    with fitz.open(file_path) as pdf:
        if pdf.needs_pass:
            raise ValueError("The PDF requires a password")
        for page in pdf:
            side = max(page.rect.width, page.rect.height)
            zoom = min(scale, max_side / side) if side else scale
            pixmap = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            image = Image.frombytes("RGB", (pixmap.width, pixmap.height), pixmap.samples)
            output = io.BytesIO()
            image.save(output, format="JPEG", quality=quality, optimize=True)
            pages.append(base64.b64encode(output.getvalue()).decode("ascii"))
    return pages


if __name__ == "__main__":
    try:
        json.dump(render(sys.argv[1], json.loads(sys.argv[2])), sys.stdout, separators=(",", ":"))
    except Exception as error:
        print(f"Native PDF render failed: {error}", file=sys.stderr)
        sys.exit(1)
