const fs = require("node:fs");
const path = require("node:path");
const { PDFDocument } = require("pdf-lib");
const { Jimp, JimpMime } = require("jimp");

function pageId(fileIndex, pageIndex) { return `${fileIndex}:${pageIndex}`; }

function validatePageOrder(order, pageCounts) {
  if (!Array.isArray(order) || !Array.isArray(pageCounts)) return false;
  const expected = pageCounts.flatMap((count, fileIndex) =>
    Array.from({ length: count }, (_unused, pageIndex) => pageId(fileIndex, pageIndex)));
  return order.length === expected.length && expected.length > 0 &&
    order.every((id) => typeof id === "string") &&
    new Set(order).size === expected.length &&
    order.every((id) => expected.includes(id));
}

async function imageThumbnail(filePath) {
  const image = await Jimp.read(await fs.promises.readFile(filePath));
  const ratio = Math.min(1, 320 / image.width, 360 / image.height);
  if (ratio < 1) image.resize({ w: Math.max(1, Math.round(image.width * ratio)) });
  const jpg = await image.getBuffer(JimpMime.jpeg, { quality: 72 });
  return `data:image/jpeg;base64,${Buffer.from(jpg).toString("base64")}`;
}

async function createPagePreviews(slug, files, renderPdfToJpg) {
  if (!["jpg-to-pdf", "png-to-pdf", "merge-pdf"].includes(slug)) throw new Error("Unsupported page-order shortcut.");
  const pages = [];
  const pageCounts = [];
  const warnings = [];
  for (let fileIndex = 0; fileIndex < files.length; fileIndex += 1) {
    const filePath = files[fileIndex];
    const filename = path.basename(filePath);
    if (slug === "merge-pdf") {
      let document;
      try { document = await PDFDocument.load(await fs.promises.readFile(filePath)); }
      catch { throw new Error(`${filename} could not be opened. It may be locked or damaged.`); }
      const count = document.getPageCount();
      if (!count) throw new Error(`${filename} has no pages.`);
      pageCounts.push(count);
      let thumbnails = [];
      try {
        thumbnails = await renderPdfToJpg(filePath, { scale: 0.45, quality: 0.65, maximumSide: 550 });
        if (!Array.isArray(thumbnails) || thumbnails.length !== count) throw new Error("Page preview count differs from the PDF.");
      } catch {
        warnings.push(`${filename}: thumbnails unavailable; page numbers can still be reordered.`);
        thumbnails = [];
      }
      for (let pageIndex = 0; pageIndex < count; pageIndex += 1) {
        pages.push({
          id: pageId(fileIndex, pageIndex), filename, pageNumber: pageIndex + 1,
          preview: thumbnails[pageIndex] ? `data:image/jpeg;base64,${thumbnails[pageIndex]}` : "",
        });
      }
    } else {
      pageCounts.push(1);
      let preview = "";
      try { preview = await imageThumbnail(filePath); }
      catch { warnings.push(`${filename}: thumbnail unavailable; the file will be checked before creating the PDF.`); }
      pages.push({ id: pageId(fileIndex, 0), filename, pageNumber: 1, preview });
    }
  }
  return { pages, pageCounts, warnings };
}

module.exports = { pageId, validatePageOrder, createPagePreviews };
