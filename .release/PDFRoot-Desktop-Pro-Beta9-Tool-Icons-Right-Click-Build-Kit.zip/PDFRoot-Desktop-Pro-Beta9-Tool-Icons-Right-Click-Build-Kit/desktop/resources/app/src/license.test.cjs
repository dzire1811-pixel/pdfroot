const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const test = require("node:test");
const { createLicenseCode, verifyLicenseCode } = require("./license.cjs");

function createKeys() {
  return crypto.generateKeyPairSync("ed25519", {
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
    publicKeyEncoding: { type: "spki", format: "pem" },
  });
}

function payload(overrides = {}) {
  return {
    version: 1,
    issuer: "PDFRoot",
    licenseId: "PDR-TEST-1",
    plan: "monthly",
    customerName: "Test customer",
    deviceHash: "DEVICE-123",
    issuedAt: "2026-09-01T00:00:00.000Z",
    expiresAt: "2026-10-01T00:00:00.000Z",
    features: ["all-tools"],
    ...overrides,
  };
}

test("accepts a correctly signed active monthly code", () => {
  const keys = createKeys();
  const code = createLicenseCode(payload(), keys.privateKey);
  const result = verifyLicenseCode(code, { publicKeyPem: keys.publicKey, deviceHash: "DEVICE-123", now: new Date("2026-09-20T00:00:00Z") });
  assert.equal(result.ok, true);
  assert.equal(result.state, "active");
});

test("accepts existing and new seller keys without invalidating active customers", () => {
  const oldKeys = createKeys();
  const sellerKeys = createKeys();
  const publicKeyPem = `${oldKeys.publicKey}\n${sellerKeys.publicKey}`;
  for (const privateKey of [oldKeys.privateKey, sellerKeys.privateKey]) {
    const code = createLicenseCode(payload(), privateKey);
    assert.equal(verifyLicenseCode(code, {
      publicKeyPem, deviceHash: "DEVICE-123", now: new Date("2026-09-20T00:00:00Z"),
    }).ok, true);
  }
  const unknownKey = createKeys();
  assert.equal(verifyLicenseCode(createLicenseCode(payload(), unknownKey.privateKey), {
    publicKeyPem, deviceHash: "DEVICE-123", now: new Date("2026-09-20T00:00:00Z"),
  }).ok, false);
});

test("rejects a code for another computer", () => {
  const keys = createKeys();
  const code = createLicenseCode(payload(), keys.privateKey);
  const result = verifyLicenseCode(code, { publicKeyPem: keys.publicKey, deviceHash: "OTHER-PC", now: new Date("2026-09-20T00:00:00Z") });
  assert.equal(result.ok, false);
  assert.equal(result.state, "device-mismatch");
});

test("allows exactly three renewal-grace days then expires", () => {
  const keys = createKeys();
  const code = createLicenseCode(payload(), keys.privateKey);
  const grace = verifyLicenseCode(code, { publicKeyPem: keys.publicKey, deviceHash: "DEVICE-123", now: new Date("2026-10-03T23:59:59Z") });
  const expired = verifyLicenseCode(code, { publicKeyPem: keys.publicKey, deviceHash: "DEVICE-123", now: new Date("2026-10-04T00:00:01Z") });
  assert.equal(grace.ok, true);
  assert.equal(grace.state, "grace");
  assert.equal(expired.ok, false);
  assert.equal(expired.state, "expired");
});

test("payment-backed license expires at the 30-day boundary without grace", () => {
  const keys = createKeys();
  const code = createLicenseCode(payload({ source: "razorpay-payment" }), keys.privateKey);
  assert.equal(verifyLicenseCode(code, { publicKeyPem: keys.publicKey, deviceHash: "DEVICE-123", now: new Date("2026-09-30T23:59:59.999Z") }).ok, true);
  const expired = verifyLicenseCode(code, { publicKeyPem: keys.publicKey, deviceHash: "DEVICE-123", now: new Date("2026-10-01T00:00:00.000Z") });
  assert.equal(expired.ok, false);
  assert.equal(expired.state, "expired");
});

test("rejects a tampered code", () => {
  const keys = createKeys();
  const code = createLicenseCode(payload(), keys.privateKey);
  const [prefix, _encodedPayload, signature] = code.split(".");
  const changedPayload = Buffer.from(JSON.stringify(payload({ licenseId: "PDR-TEST-9" }))).toString("base64url");
  const tampered = `${prefix}.${changedPayload}.${signature}`;
  const result = verifyLicenseCode(tampered, { publicKeyPem: keys.publicKey, deviceHash: "DEVICE-123" });
  assert.equal(result.ok, false);
});
