const assert = require("node:assert/strict");
const test = require("node:test");
const { displayAccelerator, registerShortcutSet } = require("./shortcut-registration.cjs");

test("global shortcut registration keeps the primary key when Windows accepts it", () => {
  const registered = [];
  const results = registerShortcutSet({
    shortcuts: [{
      accelerator: "Control+Alt+J",
      display: "Ctrl + Alt + J",
      fallbackAccelerator: "Control+Alt+Shift+J",
      backupAccelerator: "Control+Shift+F3",
    }],
    unregisterAll: () => registered.push("clear"),
    register: (accelerator) => { registered.push(accelerator); return true; },
    handler: () => {},
  });

  assert.deepEqual(registered, ["clear", "Control+Alt+J", "Control+Alt+Shift+J", "Control+Shift+F3"]);
  assert.deepEqual(results.get("Control+Alt+J"), {
    registered: true,
    effectiveAccelerator: "Control+Alt+J",
    effectiveDisplay: "Ctrl + Alt + J",
    usedFallback: false,
    candidates: ["Control+Alt+J", "Control+Alt+Shift+J", "Control+Shift+F3"],
    registeredAccelerators: ["Control+Alt+J", "Control+Alt+Shift+J", "Control+Shift+F3"],
    alternateAccelerators: ["Control+Alt+Shift+J", "Control+Shift+F3"],
    alternateDisplays: ["Ctrl + Alt + Shift + J", "Ctrl + Shift + F3"],
  });
});

test("global shortcut registration uses the shown fallback if the primary key is occupied", () => {
  const attempts = [];
  const results = registerShortcutSet({
    shortcuts: [{
      accelerator: "Control+Alt+R",
      display: "Ctrl + Alt + R",
      fallbackAccelerator: "Control+Alt+Shift+R",
      backupAccelerator: "Control+Shift+F1",
    }],
    unregisterAll: () => {},
    register: (accelerator) => {
      attempts.push(accelerator);
      return accelerator === "Control+Alt+Shift+R" || accelerator === "Control+Shift+F1";
    },
    handler: () => {},
  });

  assert.deepEqual(attempts, ["Control+Alt+R", "Control+Alt+Shift+R", "Control+Shift+F1"]);
  assert.equal(results.get("Control+Alt+R").effectiveDisplay, "Ctrl + Alt + Shift + R");
  assert.equal(results.get("Control+Alt+R").usedFallback, true);
  assert.deepEqual(results.get("Control+Alt+R").alternateDisplays, ["Ctrl + Shift + F1"]);
});

test("a busy shortcut is reported without preventing other bindings", () => {
  const results = registerShortcutSet({
    shortcuts: [
      {
        accelerator: "Control+Alt+M",
        display: "Ctrl + Alt + M",
        fallbackAccelerator: "Control+Alt+Shift+M",
        backupAccelerator: "Control+Shift+F4",
      },
      {
        accelerator: "Control+Alt+J",
        display: "Ctrl + Alt + J",
        fallbackAccelerator: "Control+Alt+Shift+J",
        backupAccelerator: "Control+Shift+F3",
      },
    ],
    unregisterAll: () => {},
    register: (accelerator) => accelerator.endsWith("+J"),
    handler: () => {},
  });

  assert.equal(results.get("Control+Alt+M").registered, false);
  assert.equal(results.get("Control+Alt+J").registered, true);
});

test("accelerators get a readable Windows label", () => {
  assert.equal(displayAccelerator("Control+Alt+Shift+F1"), "Ctrl + Alt + Shift + F1");
});
