@echo off
setlocal
cd /d "%~dp0desktop\resources\app"
if errorlevel 1 goto fail
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required to build the installer. Install Node.js LTS and try again.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto fail
call npm test
if errorlevel 1 goto fail
call npm run pack:win
if errorlevel 1 goto fail
if not exist "release\beta.yml" (
  echo Auto-update metadata beta.yml was not created. Build stopped.
  goto fail
)
echo.
echo Installer and beta.yml are in desktop\resources\app\release\
explorer "%CD%\release"
pause
exit /b 0
:fail
echo Build stopped. Please send a screenshot of the error.
pause
exit /b 1
